(() => {
  "use strict";

  const form = document.querySelector("#inviteForm");
  const input = document.querySelector("#inviteCode");
  const button = document.querySelector("#enterButton");
  const buttonLabel = button.querySelector("span");
  const pasteButton = document.querySelector("#pasteButton");
  const errorBox = document.querySelector("#formError");
  const hint = document.querySelector("#formHint");
  const card = document.querySelector(".access-card");
  const params = new URLSearchParams(window.location.search);
  const preset = params.get("invite") || "";
  const next = params.get("next") || "/";
  let loading = false;

  if (preset) {
    input.value = preset;
    hint.textContent = "已从邀请链接读取访问码，点击下方按钮进入。";
    hint.classList.add("is-ok");
    // Keep the long-lived invite token out of the address bar and history.
    window.history.replaceState({}, "", "/login");
    button.focus();
  } else {
    input.focus();
  }

  if (params.get("expired")) {
    showError("这个邀请链接已失效，请向邀请人索取新的链接。");
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
    card.classList.remove("has-error");
    void card.offsetWidth;
    card.classList.add("has-error");
  }

  function clearError() {
    errorBox.hidden = true;
    card.classList.remove("has-error");
  }

  input.addEventListener("input", clearError);

  pasteButton.addEventListener("click", async () => {
    clearError();
    try {
      const text = await navigator.clipboard.readText();
      if (text.trim()) {
        input.value = text.trim();
        input.focus();
      }
    } catch {
      input.focus();
      hint.textContent = "浏览器未授权读取剪贴板，请手动粘贴邀请码。";
      hint.classList.remove("is-ok");
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (loading) return;
    const invite = input.value.trim();
    if (!invite) {
      showError("请先输入邀请码。");
      input.focus();
      return;
    }

    loading = true;
    clearError();
    button.disabled = true;
    button.classList.add("is-loading");
    button.setAttribute("aria-busy", "true");
    buttonLabel.textContent = "正在验证邀请";
    hint.textContent = "正在确认访问权限…";
    hint.classList.remove("is-ok");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ invite, next }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.ok) {
        throw new Error(payload.message || "邀请码无效或已过期");
      }
      buttonLabel.textContent = "已通过，正在进入";
      window.location.assign(payload.redirect || "/");
    } catch (error) {
      loading = false;
      button.disabled = false;
      button.classList.remove("is-loading");
      button.removeAttribute("aria-busy");
      buttonLabel.textContent = "进入沸点";
      hint.textContent = "邀请链接会自动填入访问码，只需点击进入。";
      showError(error.message || "网络连接失败，请稍后再试");
      input.focus();
      input.select();
    }
  });
})();
