/* =========================================================
   沸点 Hotwave · front-end
   ========================================================= */

(() => {
  "use strict";

  const BOOKMARK_KEY = "hotwave.bookmarks.v1";
  const PAGE_SIZE = 12;
  const WEEKDAYS = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];

  const state = {
    data: null,
    loading: true,
    refreshing: false,
    activeSource: "all",
    activeCategory: "all",
    sort: "heat",
    query: "",
    bookmarksOnly: false,
    visibleCount: PAGE_SIZE,
    activeItemId: null,
    searchIndex: -1,
    bookmarks: loadBookmarks(),
    lastFocus: null,
  };

  const els = {};

  /* =========================================================
     Helpers
     ========================================================= */

  function $(selector, root = document) {
    return root.querySelector(selector);
  }

  function $$(selector, root = document) {
    return Array.from(root.querySelectorAll(selector));
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function safeUrl(value) {
    if (!value) return "#";
    try {
      const url = new URL(value, window.location.origin);
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : "#";
    } catch {
      return "#";
    }
  }

  function safeColor(value, fallback = "#ff5a3c") {
    return /^#[0-9a-f]{3,8}$/i.test(value || "") ? value : fallback;
  }

  function icon(name) {
    return `<svg aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  }

  function formatCompact(value) {
    const number = Number(value) || 0;
    if (number >= 100_000_000) return `${(number / 100_000_000).toFixed(2)}亿`;
    if (number >= 10_000) return `${(number / 10_000).toFixed(1)}万`;
    return number.toLocaleString("zh-CN");
  }

  function formatTime(value) {
    if (!value) return "刚刚";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "刚刚";
    return date.toLocaleTimeString("zh-CN", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
  }

  function timeAgo(value) {
    const date = new Date(value).getTime();
    if (!Number.isFinite(date)) return "刚刚";
    const seconds = Math.max(0, Math.round((Date.now() - date) / 1000));
    if (seconds < 45) return "刚刚";
    if (seconds < 3600) return `${Math.floor(seconds / 60)} 分钟前`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} 小时前`;
    return `${Math.floor(seconds / 86400)} 天前`;
  }

  function categoryMeta(category) {
    return (
      state.data?.categoryMeta?.[category] || {
        color: "#736d63",
        soft: "#f0ede7",
      }
    );
  }

  function platformColor(sourceId) {
    return state.data?.sources?.find((source) => source.id === sourceId)?.color || "#736d63";
  }

  function padRank(rank) {
    return String(rank || 1).padStart(2, "0");
  }

  function platformRank(item, sourceId = state.activeSource) {
    if (sourceId === "all") return item.rank || 1;
    return item.platforms?.find((platform) => platform.source === sourceId)?.rank || item.rank || 1;
  }

  function platformScore(item, sourceId = state.activeSource) {
    if (sourceId === "all") return Number(item.heat) || 0;
    return Number(item.platforms?.find((platform) => platform.source === sourceId)?.score) || Number(item.heat) || 0;
  }

  function platformHeatText(item, sourceId = state.activeSource) {
    if (sourceId === "all") return item.heatText || "—";
    return item.platforms?.find((platform) => platform.source === sourceId)?.heatText || item.heatText || "—";
  }

  function getItem(id) {
    if (!id) return null;
    const live = state.data?.items?.find((item) => item.id === id);
    if (live) return live;
    const saved = state.bookmarks[id];
    return saved?.item || null;
  }

  function highlightMatch(text, query) {
    const source = String(text ?? "");
    if (!query) return escapeHTML(source);
    const index = source.toLocaleLowerCase().indexOf(query.toLocaleLowerCase());
    if (index < 0) return escapeHTML(source);
    return (
      escapeHTML(source.slice(0, index)) +
      "<mark>" +
      escapeHTML(source.slice(index, index + query.length)) +
      "</mark>" +
      escapeHTML(source.slice(index + query.length))
    );
  }

  function initials(source) {
    return source === "bilibili" ? "B" : (state.data?.sources?.find((item) => item.id === source)?.short || "?");
  }

  /* =========================================================
     Bookmarks
     ========================================================= */

  function loadBookmarks() {
    try {
      const raw = JSON.parse(localStorage.getItem(BOOKMARK_KEY) || "{}");
      if (!raw || Array.isArray(raw) || typeof raw !== "object") return {};
      const clean = {};
      for (const [id, entry] of Object.entries(raw)) {
        if (entry?.item?.title) clean[id] = entry;
      }
      return clean;
    } catch {
      return {};
    }
  }

  function persistBookmarks() {
    try {
      localStorage.setItem(BOOKMARK_KEY, JSON.stringify(state.bookmarks));
    } catch {
      showToast("浏览器存储空间不足，关注仅保留在本次会话");
    }
  }

  function isBookmarked(id) {
    return Boolean(state.bookmarks[id]);
  }

  function toggleBookmark(id) {
    if (!id) return;
    if (state.bookmarks[id]) {
      delete state.bookmarks[id];
      persistBookmarks();
      syncBookmarkUI();
      renderFeed();
      showToast("已从我的关注移除");
      return;
    }
    const item = getItem(id);
    if (!item) return;
    state.bookmarks[id] = {
      savedAt: new Date().toISOString(),
      item: JSON.parse(JSON.stringify(item)),
    };
    persistBookmarks();
    syncBookmarkUI();
    renderFeed();
    showToast("已加入我的关注");
  }

  function syncBookmarkUI() {
    const count = Object.keys(state.bookmarks).length;
    els.navBookmarkCount.textContent = String(count);
    els.mobileBookmarkCount.textContent = String(count);
    els.mobileBookmarkCount.hidden = count === 0;
    $$("[data-bookmark]").forEach((button) => {
      const active = isBookmarked(button.dataset.bookmark);
      button.classList.toggle("is-active", active);
      button.classList.toggle("is-bookmarked", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
      const label = $(".bookmark-text", button);
      if (label) label.textContent = active ? "已关注" : "关注";
      button.setAttribute(
        "aria-label",
        active ? "取消关注此话题" : "关注此话题"
      );
    });
  }

  /* =========================================================
     Data loading
     ========================================================= */

  async function loadData(force = false) {
    if (state.refreshing) return;
    state.refreshing = true;
    els.refreshBtn.classList.add("is-loading");
    els.refreshBtn.disabled = true;
    try {
      const response = await fetch(`/api/hot${force ? "?refresh=1" : ""}`, {
        cache: "no-store",
        headers: { Accept: "application/json" },
      });
      if (response.status === 401) {
        const unauthorized = await response.json().catch(() => ({}));
        window.location.assign(unauthorized.loginUrl || "/login");
        return;
      }
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = await response.json();
      if (!payload.ok) throw new Error(payload.message || "数据接口返回异常");
      state.data = payload;
      state.loading = false;
      if (
        state.activeCategory !== "all" &&
        !(payload.stats?.categoryCounts?.[state.activeCategory] > 0)
      ) {
        state.activeCategory = "all";
      }
      renderAll();
      if (force) {
        const live = payload.stats?.liveSources ?? 0;
        showToast(`已同步 ${live} 个平台 · ${payload.stats?.totalTopics ?? 0} 个话题`);
      }
    } catch (error) {
      console.error("Hotwave load failed:", error);
      if (!state.data) {
        state.loading = false;
        renderError();
      } else if (force) {
        showToast("刷新失败，正在展示上一次成功的数据");
      }
    } finally {
      state.refreshing = false;
      els.refreshBtn.classList.remove("is-loading");
      els.refreshBtn.disabled = false;
      tickTimeLabels();
    }
  }

  function renderAll() {
    if (!state.data) return;
    tickDateLabel();
    renderHero();
    renderStats();
    renderSources();
    renderTabs();
    renderCategories();
    renderFeed();
    renderRail();
    renderNotifications();
    renderAbout();
    syncBookmarkUI();
    els.searchPopover.hidden ? null : renderSearchPopover();
  }

  /* =========================================================
     Header + hero
     ========================================================= */

  function tickDateLabel() {
    const now = new Date();
    els.todayLabel.textContent = `${now.getMonth() + 1}月${now.getDate()}日 · ${WEEKDAYS[now.getDay()]}`;
  }

  function tickTimeLabels() {
    if (!state.data) return;
    const generated = state.data.generatedAt;
    const updated = `更新于 ${formatTime(generated)} · ${timeAgo(generated)}`;
    const heroUpdated = $("#heroUpdated");
    if (heroUpdated) heroUpdated.textContent = updated;
    els.lastUpdated.textContent = `${formatTime(generated)} 更新 · 缓存 ${Math.round((state.data.cacheTtl || 180) / 60)} 分钟`;
  }

  function renderHero() {
    const item = state.data?.items?.[0];
    if (!item) {
      renderError();
      return;
    }
    const meta = categoryMeta(item.category);
    const platforms = item.platforms || [];
    const bookmark = isBookmarked(item.id);
    const liveCount = Number(state.data?.stats?.liveSources || 0);
    const sourceTotal = Number(state.data?.stats?.sourceCount || 5);
    const allCached = liveCount === 0;
    const angles = [-90, -18, 54, 126, 198];
    const radii = [80, 72, 80, 72, 80];
    const dots = platforms
      .slice(0, 5)
      .map((platform, index) => {
        const color = safeColor(platform.color || platformColor(platform.source));
        return `<span class="radar-dot" style="--angle:${angles[index]}deg;--radius:${radii[index]}px;--dot-color:${color};--source-color:${color}" data-label="${escapeHTML(platform.short || platform.name)}">${escapeHTML(platform.short || platform.name)}</span>`;
      })
      .join("");

    els.heroCard.setAttribute("aria-busy", "false");
    els.heroCard.innerHTML = `
      <div class="hero-mesh" aria-hidden="true"></div>
      <div class="hero-top">
        <span class="live-badge ${allCached ? "is-cached" : ""}"><i class="live-dot"></i> ${allCached ? "CACHED · 缓存快照" : `LIVE · ${liveCount}/${sourceTotal} 在线`}</span>
        <span class="hero-updated" id="heroUpdated">更新于 ${formatTime(state.data.generatedAt)} · 刚刚</span>
      </div>
      <div class="hero-main">
        <div class="hero-copy">
          <div class="hero-kicker">
            <span class="hero-rank">TOP ${padRank(item.rank)}</span>
            <span class="divider"></span>
            <span>综合热度第一</span>
            <span class="divider"></span>
            <span>${escapeHTML(item.category)}</span>
          </div>
          <button class="hero-title" type="button" data-open-item="${escapeHTML(item.id)}">${escapeHTML(item.title)}</button>
          <p class="hero-desc">
            来自 <strong>${escapeHTML(platforms.map((platform) => platform.name).join("、"))}</strong> 的${allCached ? "缓存样本" : "实时热榜"}
            · 站内热度指数 <strong>${Number(item.heat).toFixed(1)}</strong>
            · ${platforms.length > 1 ? `已在 ${platforms.length} 个平台形成共振` : "正在持续升温"}
          </p>
          <div class="hero-actions">
            <button class="primary-button" type="button" data-open-item="${escapeHTML(item.id)}">
              查看话题 ${icon("arrow-right")}
            </button>
            <button class="ghost-button ${bookmark ? "is-bookmarked" : ""}" type="button" data-bookmark="${escapeHTML(item.id)}" aria-pressed="${bookmark}" aria-label="${bookmark ? "取消关注此话题" : "关注此话题"}">
              ${icon(bookmark ? "bookmark-filled" : "bookmark")}
              <span class="bookmark-text">${bookmark ? "已关注" : "关注"}</span>
            </button>
          </div>
        </div>
        <div class="hero-radar" aria-hidden="true">
          <span class="radar-ring radar-ring--one"></span>
          <span class="radar-ring radar-ring--two"></span>
          <span class="radar-ring radar-ring--three"></span>
          <span class="radar-sweep"></span>
          <span class="radar-core"><span>HEAT INDEX</span><strong>${Number(item.heat).toFixed(1)}</strong></span>
          ${dots}
        </div>
      </div>
      <div class="hero-footer">
        <div class="hero-metrics">
          <span class="hero-metric"><span>最高排名</span><b>#${escapeHTML(item.rank)}</b></span>
          <span class="hero-metric"><span>来源读数</span><b>${escapeHTML(item.heatText)}</b></span>
          <span class="hero-metric"><span>在榜平台</span><b>${platforms.length} 个</b></span>
        </div>
        <div class="hero-source-chips">
          ${platforms
            .slice(0, 5)
            .map(
              (platform) =>
                `<span class="hero-source-chip" style="--source-color:${safeColor(platform.color)}"><i></i>${escapeHTML(platform.name)} #${escapeHTML(platform.rank)}</span>`
            )
            .join("")}
        </div>
      </div>
    `;
  }

  function renderStats() {
    const stats = state.data?.stats || {};
    const sourceCounts = state.data?.stats?.sourceCounts || {};
    const sources = state.data?.sources || [];
    const maxSource = Math.max(1, ...Object.values(sourceCounts));
    const sourceBars = sources
      .map((source) => {
        const count = Number(sourceCounts[source.id] || 0);
        const height = 5 + Math.round((count / maxSource) * 14);
        return `<i style="--bar:${height}px"></i>`;
      })
      .join("");
    const categoryCounts = stats.categoryCounts || {};
    const maxCategory = Math.max(1, ...Object.values(categoryCounts));
    const categoryBars = Object.values(categoryCounts)
      .slice(0, 6)
      .map((count) => `<i style="--bar:${5 + Math.round((count / maxCategory) * 14)}px"></i>`)
      .join("");

    els.heroSide.innerHTML = `
      <article class="stat-card stat-card--soft">
        <div class="stat-label"><span>全网热度</span><span class="stat-icon">${icon("flame")}</span></div>
        <div class="stat-value">${formatCompact(stats.totalHeat)}</div>
        <div class="stat-foot"><span class="up">${stats.liveSources}/${stats.sourceCount}</span> 个平台原始热度合计</div>
        <div class="mini-bars" aria-hidden="true">${sourceBars}</div>
      </article>
      <article class="stat-card">
        <div class="stat-label"><span>在榜话题</span><span class="stat-icon">${icon("grid")}</span></div>
        <div class="stat-value">${Number(stats.totalTopics || 0).toLocaleString("zh-CN")}<small>个</small></div>
        <div class="stat-foot">跨平台去重后收录</div>
        <div class="mini-bars" aria-hidden="true">${categoryBars}</div>
      </article>
      <article class="stat-card stat-card--dark">
        <div class="stat-label"><span>跨平台共振</span><span class="stat-icon">${icon("radar")}</span></div>
        <div class="stat-value">${Number(stats.crossPlatform || 0)}<small>个</small></div>
        <div class="stat-foot"><span class="up">${stats.crossPlatform ? "MULTI" : "SINGLE"}</span> 多平台同时上榜</div>
        <div class="mini-bars" aria-hidden="true">${sourceBars}</div>
      </article>
      <article class="stat-card">
        <div class="stat-label"><span>数据源</span><span class="stat-icon">${icon("chart")}</span></div>
        <div class="stat-value">${Number(stats.liveSources || 0)}<small>/ ${Number(stats.sourceCount || 5)}</small></div>
        <div class="stat-live-row"><i class="pulse-dot"></i> ${stats.liveSources === stats.sourceCount ? "全部在线" : "部分使用缓存"}</div>
        <div class="stat-foot">最近同步 ${formatTime(state.data.generatedAt)}</div>
      </article>
    `;
  }

  /* =========================================================
     Sidebar + tabs + filters
     ========================================================= */

  function renderSources() {
    const sources = state.data?.sources || [];
    const counts = state.data?.stats?.sourceCounts || {};
    const live = sources.filter((source) => source.status === "live").length;
    els.sourceHealth.innerHTML = `<i></i> ${live}/${sources.length} 在线`;
    els.sourceHealth.classList.toggle("is-warn", live < sources.length);
    els.sourceList.innerHTML = sources
      .map((source) => {
        const active = state.activeSource === source.id && !state.bookmarksOnly;
        const statusClass =
          source.status === "live"
            ? ""
            : source.status === "cached"
              ? " is-cached"
              : " is-offline";
        return `
          <button class="source-item ${active ? "is-active" : ""}" type="button" data-source-filter="${escapeHTML(source.id)}" aria-pressed="${active}">
            <span class="source-glyph" style="--source-color:${safeColor(source.color)}">${escapeHTML(source.short)}</span>
            <span>${escapeHTML(source.name)}</span>
            <span class="source-item-count">${Number(counts[source.id] || source.count || 0)}</span>
            <i class="source-item-status${statusClass}" title="${source.status === "live" ? "在线" : source.status === "cached" ? "缓存" : "离线"}"></i>
          </button>
        `;
      })
      .join("");
    els.navTopicCount.textContent = Number(state.data?.stats?.totalTopics || 0);
  }

  function renderTabs() {
    const sources = state.data?.sources || [];
    const items = state.data?.items || [];
    const counts = {};
    sources.forEach((source) => {
      counts[source.id] = items.filter((item) =>
        item.platforms?.some((platform) => platform.source === source.id)
      ).length;
    });
    els.sourceTabs.innerHTML = `
      <button class="source-tab ${state.activeSource === "all" && !state.bookmarksOnly ? "is-active" : ""}" type="button" data-source-tab="all" role="tab" aria-selected="${state.activeSource === "all" && !state.bookmarksOnly}">
        <span class="tab-dot tab-dot--all"></span> 综合
        <span class="tab-count">${items.length}</span>
      </button>
      ${sources
        .map(
          (source) => `
            <button class="source-tab ${state.activeSource === source.id && !state.bookmarksOnly ? "is-active" : ""}" type="button" data-source-tab="${escapeHTML(source.id)}" role="tab" aria-selected="${state.activeSource === source.id && !state.bookmarksOnly}">
              <span class="tab-dot" style="--source-color:${safeColor(source.color)}"></span>
              ${escapeHTML(source.name)}
              <span class="tab-count">${counts[source.id] || 0}</span>
            </button>
          `
        )
        .join("")}
    `;
  }

  function sourceFilteredItems() {
    const source = state.data?.items || [];
    if (state.activeSource === "all") return source;
    return source.filter((item) =>
      item.platforms?.some((platform) => platform.source === state.activeSource)
    );
  }

  function renderCategories() {
    const items = state.bookmarksOnly ? savedItems() : sourceFilteredItems();
    const counts = {};
    items.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    const categories = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([name]) => name);
    if (state.activeCategory !== "all" && !counts[state.activeCategory]) {
      state.activeCategory = "all";
    }
    const chips = [
      `<button class="category-chip ${state.activeCategory === "all" ? "is-active" : ""}" type="button" data-category="all" aria-pressed="${state.activeCategory === "all"}">全部</button>`,
      ...categories.map(
        (name) =>
          `<button class="category-chip ${state.activeCategory === name ? "is-active" : ""}" type="button" data-category="${escapeHTML(name)}" aria-pressed="${state.activeCategory === name}">${escapeHTML(name)} <span style="opacity:.55;font-size:7.5px">${counts[name]}</span></button>`
      ),
    ];
    els.categoryChips.innerHTML = chips.join("");
  }

  /* =========================================================
     Feed
     ========================================================= */

  function savedItems() {
    return Object.entries(state.bookmarks)
      .map(([id, entry]) => {
        const live = state.data?.items?.find((item) => item.id === id);
        return live ? { ...live, savedAt: entry.savedAt } : entry.item;
      })
      .filter(Boolean);
  }

  function baseItems() {
    return state.bookmarksOnly ? savedItems() : state.data?.items || [];
  }

  function filteredItems() {
    let items = baseItems();
    if (state.activeSource !== "all") {
      items = items.filter((item) =>
        item.platforms?.some((platform) => platform.source === state.activeSource)
      );
    }
    if (state.activeCategory !== "all") {
      items = items.filter((item) => item.category === state.activeCategory);
    }
    if (state.query) {
      const tokens = state.query.toLocaleLowerCase().split(/\s+/).filter(Boolean);
      items = items.filter((item) => {
        const haystack = [
          item.title,
          item.category,
          item.sourceName,
          ...(item.platforms || []).map((platform) => platform.name),
        ]
          .join(" ")
          .toLocaleLowerCase();
        return tokens.every((token) => haystack.includes(token));
      });
    }
    const sorted = [...items];
    if (state.sort === "rank") {
      sorted.sort(
        (a, b) =>
          platformRank(a) - platformRank(b) ||
          Number(b.heat || 0) - Number(a.heat || 0)
      );
    } else {
      sorted.sort(
        (a, b) =>
          Number(b.heat || 0) - Number(a.heat || 0) ||
          platformRank(a) - platformRank(b)
      );
    }
    return sorted;
  }

  function movementMarkup(item) {
    if (item.isNew) return `<span class="rank-move is-new">NEW</span>`;
    const change = Number(item.rankChange || 0);
    if (change > 0) return `<span class="rank-move is-up">↑${change}</span>`;
    if (change < 0) return `<span class="rank-move is-down">↓${Math.abs(change)}</span>`;
    return "";
  }

  function feedItemMarkup(item, index = 0) {
    const bookmark = isBookmarked(item.id);
    const rank =
      state.activeSource === "all" ? index + 1 : platformRank(item);
    const score = platformScore(item);
    const heatText = platformHeatText(item);
    const category = item.category || "其他";
    const meta = categoryMeta(category);
    const platforms = item.platforms || [];
    const label = item.label && item.label !== "缓存" ? item.label : "";
    const labelClass = label === "新" ? "is-new" : "is-hot";
    return `
      <article class="feed-item ${bookmark ? "is-bookmarked" : ""}" data-open-item="${escapeHTML(item.id)}" tabindex="0" role="button" aria-label="查看话题：${escapeHTML(item.title)}">
        <div class="rank-block">
          <span class="rank-number">${padRank(rank)}</span>
          ${movementMarkup(item)}
        </div>
        <div class="feed-copy">
          <h3 class="feed-title">${escapeHTML(item.title)}</h3>
          <div class="feed-meta">
            <span class="source-pill" style="--source-color:${safeColor(item.sourceColor)}"><i></i>${escapeHTML(item.sourceName)}</span>
            <span class="meta-divider"></span>
            <span style="color:${safeColor(meta.color)}">${escapeHTML(category)}</span>
            ${platforms.length > 1 ? `<span class="meta-badge is-multi">${platforms.length} 平台在榜</span>` : ""}
            ${label ? `<span class="meta-badge ${labelClass}">${escapeHTML(label)}</span>` : ""}
            ${item.label === "缓存" ? `<span class="meta-badge">缓存</span>` : ""}
          </div>
        </div>
        <div class="heat-block" title="站内热度指数">
          <div class="heat-value">${Number(score).toFixed(1)}</div>
          <div class="heat-label">热度指数 · ${escapeHTML(heatText)}</div>
          <div class="heat-track" aria-hidden="true"><i style="width:${Math.min(100, Math.max(0, score))}%"></i></div>
        </div>
        <button class="feed-action ${bookmark ? "is-active" : ""}" type="button" data-bookmark="${escapeHTML(item.id)}" aria-label="${bookmark ? "取消关注此话题" : "关注此话题"}" aria-pressed="${bookmark}">
          ${icon("bookmark")}
        </button>
        <a class="feed-action external" href="${escapeHTML(safeUrl(item.url))}" target="_blank" rel="noopener noreferrer" aria-label="在 ${escapeHTML(item.sourceName)} 查看">
          ${icon("external")}
        </a>
      </article>
    `;
  }

  function renderFeed() {
    if (!state.data && !state.bookmarksOnly) return;
    const items = filteredItems();
    const visible = items.slice(0, state.visibleCount);
    const title = state.bookmarksOnly ? "我的关注" : "实时热榜";
    els.feedTitle.innerHTML = `${title} <span class="title-count">${items.length}</span>`;
    els.feedHeadCount.textContent = String(items.length);
    els.resultMeta.textContent = state.query
      ? `${items.length} 条匹配`
      : state.bookmarksOnly
        ? `${items.length} 个关注话题`
        : `${items.length} 个话题在榜`;
    const emptyTitle = $(".empty-state h3", els.emptyState);
    const emptyCopy = $(".empty-state p", els.emptyState);
    if (emptyTitle) {
      emptyTitle.textContent =
        state.bookmarksOnly && !items.length
          ? "还没有关注任何话题"
          : "没有找到匹配的热点";
    }
    if (emptyCopy) {
      emptyCopy.textContent =
        state.bookmarksOnly && !items.length
          ? "点击热榜条目旁的收藏按钮，把关心的话题留在这里。"
          : "换一个关键词，或清除当前筛选条件。";
    }
    if (els.resetFilters) {
      els.resetFilters.textContent =
        state.bookmarksOnly && !items.length ? "去发现热点" : "清除筛选";
    }
    els.emptyState.hidden = items.length !== 0;
    els.feedList.hidden = items.length === 0;
    els.loadMore.hidden = items.length === 0 || visible.length >= items.length;
    els.feedList.innerHTML = visible.map((item, index) => feedItemMarkup(item, index)).join("");
    els.loadMore.innerHTML = `展开更多热点（${Math.max(0, items.length - visible.length)}） ${icon("chevron-down")}`;
    syncBookmarkUI();
    tickTimeLabels();
  }

  /* =========================================================
     Right rail
     ========================================================= */

  function renderRail() {
    const stats = state.data?.stats || {};
    const sources = state.data?.sources || [];
    const sourceCounts = stats.sourceCounts || {};
    const maxCount = Math.max(1, ...Object.values(sourceCounts));
    els.liveSourceTag.textContent = `${stats.liveSources}/${stats.sourceCount} 在线`;
    els.liveSourceTag.classList.toggle("is-live", stats.liveSources === stats.sourceCount);

    els.platformBars.innerHTML = sources
      .map((source) => {
        const count = Number(sourceCounts[source.id] || 0);
        return `
          <div class="platform-row" style="--source-color:${safeColor(source.color)}">
            <span class="platform-name"><i></i>${escapeHTML(source.name)}</span>
            <span class="platform-track"><i style="--width:${Math.max(4, Math.round((count / maxCount) * 100))}%"></i></span>
            <span class="platform-count">${count}</span>
          </div>
        `;
      })
      .join("");

    const categoryCounts = stats.categoryCounts || {};
    const entries = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1]);
    const top = entries.slice(0, 5);
    const rest = entries.slice(5).reduce((total, [, count]) => total + count, 0);
    const segments = [];
    let cursor = 0;
    top.forEach(([name, count]) => {
      const percentage = (count / Math.max(1, stats.totalTopics)) * 100;
      const color = categoryMeta(name).color;
      segments.push(`${color} ${cursor}% ${cursor + percentage}%`);
      cursor += percentage;
    });
    if (rest > 0) {
      segments.push(`#cfc7b9 ${cursor}% 100%`);
    }
    if (!segments.length) segments.push("#eee8dc 0% 100%");
    els.categoryDonut.style.setProperty("--segments", segments.join(","));
    els.donutTotal.textContent = Number(stats.totalTopics || 0);
    els.categoryLegend.innerHTML = [
      ...top.map(([name, count]) => {
        const percentage = Math.round((count / Math.max(1, stats.totalTopics)) * 100);
        return `<div class="legend-row"><i style="--legend-color:${safeColor(categoryMeta(name).color)}"></i><span class="legend-name">${escapeHTML(name)}</span><span class="legend-value">${percentage}%</span></div>`;
      }),
      rest > 0
        ? `<div class="legend-row"><i style="--legend-color:#cfc7b9"></i><span class="legend-name">其他</span><span class="legend-value">${Math.round((rest / Math.max(1, stats.totalTopics)) * 100)}%</span></div>`
        : "",
    ].join("");

    els.insightText.textContent = state.data.insight || "正在读取全网信号…";
    const crossItems = state.data.items
      .filter((item) => (item.platforms || []).length > 1)
      .sort((a, b) => b.platforms.length - a.platforms.length || b.heat - a.heat)
      .slice(0, 3);
    els.crossTag.textContent = `${stats.crossPlatform || 0} 个`;
    els.resonanceList.innerHTML = crossItems.length
      ? crossItems
          .map(
            (item, index) => `
              <button class="resonance-item" type="button" data-open-item="${escapeHTML(item.id)}">
                <span class="resonance-rank">0${index + 1}</span>
                <span class="resonance-title">${escapeHTML(item.title)}</span>
                <span class="resonance-platforms">
                  ${(item.platforms || [])
                    .slice(0, 4)
                    .map(
                      (platform) =>
                        `<i style="--source-color:${safeColor(platform.color)}" title="${escapeHTML(platform.name)}">${escapeHTML(platform.short)}</i>`
                    )
                    .join("")}
                </span>
              </button>
            `
          )
          .join("")
      : `<p style="margin:8px 0 6px;color:var(--muted);font-size:10px;line-height:1.7">暂未检测到跨平台同名话题，等待下一轮同步。</p>`;
  }

  /* =========================================================
     Notifications + about
     ========================================================= */

  function renderNotifications() {
    const items = (state.data?.items || []).slice(0, 4);
    els.notifyTime.textContent = timeAgo(state.data?.generatedAt);
    els.notifyList.innerHTML = items
      .map(
        (item) => `
          <button class="notify-item" type="button" data-open-item="${escapeHTML(item.id)}">
            <span class="suggestion-glyph" style="--source-color:${safeColor(item.sourceColor)}">${escapeHTML(item.sourceShort)}</span>
            <span>
              <strong>${escapeHTML(item.title)}</strong>
              <span>${escapeHTML(item.sourceName)} · 第 ${escapeHTML(platformRank(item, "all"))} 名</span>
            </span>
            <em>${Number(item.heat).toFixed(1)}</em>
          </button>
        `
      )
      .join("");
  }

  function renderAbout() {
    const sources = state.data?.sources || [];
    els.aboutSources.innerHTML = sources
      .map(
        (source) => `
          <span class="about-source">
            <i style="--source-color:${safeColor(source.color)}"></i>
            ${escapeHTML(source.name)}
            <em>${source.status === "live" ? "在线" : source.status === "cached" ? "缓存" : "离线"}</em>
          </span>
        `
      )
      .join("");
  }

  async function loadSession() {
    try {
      const response = await fetch("/api/auth/me", {
        cache: "no-store",
        headers: { Accept: "application/json" },
      });
      if (response.status === 401) {
        window.location.assign("/login");
        return;
      }
      if (!response.ok) return;
      const payload = await response.json();
      if (payload.ok && payload.name) {
        els.sessionName.textContent = payload.name;
        const avatar = $(".avatar");
        if (avatar) {
          avatar.title = `受邀访问：${payload.name}`;
          avatar.textContent = payload.name.slice(0, 1);
        }
      }
    } catch {
      // The page remains usable if the session hint cannot be loaded.
    }
  }

  async function logout() {
    els.logoutButton.disabled = true;
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      window.location.assign("/login");
    }
  }

  /* =========================================================
     Search
     ========================================================= */

  function searchPool() {
    return state.data?.items || [];
  }

  function searchMatches(query) {
    const tokens = query.toLocaleLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) return searchPool().slice(0, 6);
    return searchPool()
      .filter((item) => {
        const haystack = [item.title, item.category, item.sourceName, ...(item.platforms || []).map((p) => p.name)]
          .join(" ")
          .toLocaleLowerCase();
        return tokens.every((token) => haystack.includes(token));
      })
      .slice(0, 8);
  }

  function renderSearchPopover() {
    if (!state.data) return;
    const query = state.query;
    const matches = searchMatches(query);
    const total = query
      ? searchPool().filter((item) => {
          const haystack = [item.title, item.category, item.sourceName, ...(item.platforms || []).map((p) => p.name)]
            .join(" ")
            .toLocaleLowerCase();
          return query
            .toLocaleLowerCase()
            .split(/\s+/)
            .filter(Boolean)
            .every((token) => haystack.includes(token));
        }).length
      : searchPool().length;
    els.searchPopoverTitle.textContent = query ? "搜索热点" : "大家都在搜";
    els.searchResultCount.textContent = query ? `${total} 个结果` : "实时热榜";
    els.searchSuggestions.innerHTML = matches.length
      ? matches
          .map(
            (item, index) => `
              <button class="suggestion ${index === state.searchIndex ? "is-focused" : ""}" type="button" data-open-item="${escapeHTML(item.id)}" data-suggestion-index="${index}">
                <span class="suggestion-glyph" style="--source-color:${safeColor(item.sourceColor)}">${escapeHTML(item.sourceShort)}</span>
                <span class="suggestion-copy">
                  <strong>${highlightMatch(item.title, query)}</strong>
                  <span>${escapeHTML(item.sourceName)} · ${escapeHTML(item.category)} · 第 ${escapeHTML(platformRank(item, "all"))} 名</span>
                </span>
                <span class="suggestion-heat">${Number(item.heat).toFixed(1)}</span>
              </button>
            `
          )
          .join("")
      : `<div class="search-empty">没有找到相关热点，试试更短的关键词。</div>`;
    els.searchPopover.hidden = false;
    els.searchInput.setAttribute("aria-expanded", "true");
  }

  function openSearch() {
    if (!state.data) return;
    renderSearchPopover();
  }

  function closeSearch() {
    els.searchPopover.hidden = true;
    els.searchInput.setAttribute("aria-expanded", "false");
    state.searchIndex = -1;
  }

  function focusSearch() {
    els.searchInput.focus();
    els.searchInput.select();
    openSearch();
  }

  /* =========================================================
     Drawer
     ========================================================= */

  function openDrawer(id) {
    const item = getItem(id);
    if (!item) return;
    state.activeItemId = id;
    state.lastFocus = document.activeElement;
    renderDrawer(item);
    els.detailDrawer.hidden = false;
    els.drawerBackdrop.hidden = false;
    els.detailDrawer.scrollTop = 0;
    requestAnimationFrame(() => {
      els.detailDrawer.classList.add("is-open");
      els.drawerBackdrop.classList.add("is-open");
    });
    document.body.classList.add("is-locked");
    setTimeout(() => els.drawerClose.focus(), 80);
  }

  function closeDrawer() {
    if (els.detailDrawer.hidden) return;
    els.detailDrawer.classList.remove("is-open");
    els.drawerBackdrop.classList.remove("is-open");
    state.activeItemId = null;
    document.body.classList.remove("is-locked");
    setTimeout(() => {
      if (!els.detailDrawer.classList.contains("is-open")) {
        els.detailDrawer.hidden = true;
        els.drawerBackdrop.hidden = true;
      }
    }, 320);
    if (state.lastFocus instanceof HTMLElement) {
      state.lastFocus.focus({ preventScroll: true });
    }
  }

  function renderDrawer(item) {
    const meta = categoryMeta(item.category);
    const platforms = item.platforms || [];
    const bookmark = isBookmarked(item.id);
    const platformNames = platforms.map((platform) => platform.name);
    const tags = [
      item.category,
      item.label && item.label !== "缓存" ? item.label : "",
      platforms.length > 1 ? `跨平台 ${platforms.length}` : "",
      ...platformNames,
    ].filter(Boolean);
    let note;
    if (platforms.length > 1) {
      note = `该话题同时出现在 ${platformNames.join("、")}。跨平台重复出现，说明讨论正在从单一榜单外溢。`;
    } else {
      note = `目前主要出现在${item.sourceName}榜单，站内尚未检测到同名话题在其他平台出现。`;
    }

    els.drawerContent.innerHTML = `
      <div class="drawer-source-row">
        <span class="source-badge" style="--source-color:${safeColor(item.sourceColor)}">${escapeHTML(item.sourceShort)} · ${escapeHTML(item.sourceName)}</span>
        <span class="drawer-category" style="--cat-color:${safeColor(meta.color)};--cat-soft:${safeColor(meta.soft)}">${escapeHTML(item.category)}</span>
        <span class="drawer-rank-badge">榜单 #${escapeHTML(platformRank(item, "all"))}</span>
      </div>
      <h2 class="drawer-title" id="drawerTitle">${escapeHTML(item.title)}</h2>
      <p class="drawer-sub">
        当前最高位列 ${escapeHTML(item.sourceName)} 第 ${escapeHTML(platformRank(item, "all"))} 名，站内综合热度指数 ${Number(item.heat).toFixed(1)}。
        数据同步于 ${formatTime(state.data?.generatedAt)}。
      </p>
      <div class="drawer-metrics">
        <div class="drawer-metric"><span>综合热度</span><strong>${Number(item.heat).toFixed(1)}</strong></div>
        <div class="drawer-metric"><span>在榜平台</span><strong>${platforms.length}<small> 个</small></strong></div>
        <div class="drawer-metric"><span>最高排名</span><strong>#${escapeHTML(item.rank)}</strong></div>
      </div>

      <section class="drawer-section">
        <div class="drawer-section-head"><h3>跨平台表现</h3><span>${platforms.length} 个来源</span></div>
        <div class="platform-detail-list">
          ${platforms
            .map(
              (platform) => `
                <div class="platform-detail">
                  <span class="source-glyph" style="--source-color:${safeColor(platform.color)}">${escapeHTML(platform.short)}</span>
                  <span>
                    <span class="platform-detail-name">${escapeHTML(platform.name)}</span>
                    <span class="platform-detail-meta">第 ${escapeHTML(platform.rank)} 名 · 指数 ${Number(platform.score).toFixed(1)}</span>
                  </span>
                  <span class="platform-detail-right">
                    <span class="platform-detail-heat">${escapeHTML(platform.heatText)}<small>来源读数</small></span>
                    <a class="platform-link" href="${escapeHTML(safeUrl(platform.url))}" target="_blank" rel="noopener noreferrer" aria-label="在 ${escapeHTML(platform.name)} 查看">
                      ${icon("arrow-up-right")}
                    </a>
                  </span>
                </div>
              `
            )
            .join("")}
        </div>
      </section>

      <section class="drawer-section">
        <div class="drawer-section-head"><h3>话题观察</h3><span>自动生成</span></div>
        <div class="drawer-note">
          <p>${escapeHTML(note)} <strong>热度指数为站内归一化指标，不代表平台官方阅读量。</strong></p>
        </div>
      </section>

      <section class="drawer-section">
        <div class="drawer-section-head"><h3>话题标签</h3><span>TOPIC TAGS</span></div>
        <div class="drawer-tags">
          ${tags.map((tag) => `<span class="drawer-tag"># ${escapeHTML(tag)}</span>`).join("")}
        </div>
      </section>

      <div class="drawer-actions">
        <a class="primary-button" href="${escapeHTML(safeUrl(item.url))}" target="_blank" rel="noopener noreferrer">
          在${escapeHTML(item.sourceName)}查看 ${icon("external")}
        </a>
        <button class="secondary-button" type="button" data-copy-link="${escapeHTML(item.id)}" aria-label="复制链接">
          ${icon("copy")}
        </button>
        <button class="secondary-button" type="button" data-share="${escapeHTML(item.id)}" aria-label="分享话题">
          ${icon("share")}
        </button>
        <button class="secondary-button ${bookmark ? "is-active" : ""}" type="button" data-bookmark="${escapeHTML(item.id)}" aria-pressed="${bookmark}">
          ${icon("bookmark")}<span class="bookmark-text">${bookmark ? "已关注" : "关注"}</span>
        </button>
      </div>
    `;
    syncBookmarkUI();
  }

  /* =========================================================
     About
     ========================================================= */

  function openAbout() {
    els.aboutBackdrop.hidden = false;
    document.body.classList.add("is-locked");
    setTimeout(() => els.aboutClose.focus(), 60);
  }

  function closeAbout() {
    els.aboutBackdrop.hidden = true;
    if (els.detailDrawer.hidden) document.body.classList.remove("is-locked");
  }

  /* =========================================================
     Notifications, toast, copy
     ========================================================= */

  function toggleNotifications() {
    const willOpen = els.notifyPopover.hidden;
    els.notifyPopover.hidden = !willOpen;
    els.notifyBtn.setAttribute("aria-expanded", String(willOpen));
    if (willOpen) {
      closeSearch();
      els.notifyTime.textContent = timeAgo(state.data?.generatedAt);
    }
  }

  function closeNotifications() {
    els.notifyPopover.hidden = true;
    els.notifyBtn.setAttribute("aria-expanded", "false");
  }

  let toastTimer = null;
  function showToast(message) {
    els.toastText.textContent = message;
    els.toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      els.toast.classList.remove("is-visible");
    }, 2400);
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const area = document.createElement("textarea");
        area.value = text;
        area.setAttribute("readonly", "");
        area.style.position = "fixed";
        area.style.opacity = "0";
        document.body.appendChild(area);
        area.select();
        const success = document.execCommand("copy");
        area.remove();
        return success;
      } catch {
        return false;
      }
    }
  }

  async function copyLink(id) {
    const item = getItem(id);
    if (!item) return;
    const copied = await copyText(item.url);
    showToast(copied ? "来源链接已复制" : "复制失败，请手动打开来源链接");
  }

  async function shareItem(id) {
    const item = getItem(id);
    if (!item) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: `${item.title} · 沸点全网热点`,
          url: item.url,
        });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }
    const copied = await copyText(item.url);
    showToast(copied ? "分享链接已复制" : "分享失败，请手动复制链接");
  }

  /* =========================================================
     Filtering / navigation
     ========================================================= */

  function resetView(options = {}) {
    state.activeSource = "all";
    state.activeCategory = "all";
    state.bookmarksOnly = false;
    state.query = "";
    state.sort = "heat";
    state.visibleCount = PAGE_SIZE;
    if (!options.keepSearch) {
      els.searchInput.value = "";
      els.clearSearch.hidden = true;
      closeSearch();
    }
    $$("[data-sort]").forEach((button) =>
      button.classList.toggle("is-active", button.dataset.sort === "heat")
    );
  }

  function setSource(sourceId) {
    state.activeSource = sourceId;
    state.bookmarksOnly = false;
    state.activeCategory = "all";
    state.visibleCount = PAGE_SIZE;
    renderTabs();
    renderCategories();
    renderFeed();
    renderSources();
    updateNavActive("feed");
    scrollToFeed();
  }

  function setCategory(category) {
    state.activeCategory = category;
    state.visibleCount = PAGE_SIZE;
    renderCategories();
    renderFeed();
  }

  function handleNav(target) {
    if (target === "about") {
      openAbout();
      return;
    }
    if (target === "bookmarks") {
      state.bookmarksOnly = true;
      state.activeSource = "all";
      state.activeCategory = "all";
      state.query = "";
      state.visibleCount = PAGE_SIZE;
      els.searchInput.value = "";
      els.clearSearch.hidden = true;
      closeSearch();
      renderTabs();
      renderCategories();
      renderSources();
      renderFeed();
      updateNavActive("bookmarks");
      scrollToFeed();
      return;
    }
    state.bookmarksOnly = false;
    updateNavActive(target === "feed" ? "feed" : "top");
    renderTabs();
    renderCategories();
    renderSources();
    renderFeed();
    if (target === "feed") {
      scrollToFeed();
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function updateNavActive(target) {
    $$("[data-nav]").forEach((link) => {
      link.classList.toggle("is-active", link.dataset.nav === target);
    });
  }

  function scrollToFeed() {
    const top = els.feedSection.getBoundingClientRect().top + window.scrollY - 94;
    window.scrollTo({ top, behavior: "smooth" });
  }

  function renderError() {
    state.loading = false;
    els.heroCard.setAttribute("aria-busy", "false");
    els.heroCard.innerHTML = `
      <div class="hero-error">
        <span class="live-badge"><i class="live-dot"></i> SIGNAL LOST</span>
        <h2>热榜信号暂时中断</h2>
        <p>无法连接聚合服务。请确认本地服务仍在运行，然后重新连接。</p>
        <button class="primary-button" type="button" data-retry>重新连接 ${icon("refresh")}</button>
      </div>
    `;
    els.heroSide.innerHTML = "";
    els.feedList.innerHTML = "";
    els.feedList.hidden = true;
    els.emptyState.hidden = false;
    $(".empty-state h3", els.emptyState).textContent = "暂时无法读取热榜";
    $(".empty-state p", els.emptyState).textContent = "请检查服务状态后重试。";
    els.feedHeadCount.textContent = "—";
    els.resultMeta.textContent = "连接失败";
    els.loadMore.hidden = true;
    els.lastUpdated.textContent = "等待重新连接";
    syncBookmarkUI();
  }

  /* =========================================================
     Events
     ========================================================= */

  function bindEvents() {
    els.refreshBtn.addEventListener("click", () => loadData(true));

    els.searchInput.addEventListener("focus", openSearch);
    els.searchInput.addEventListener("input", (event) => {
      state.query = event.target.value.trim();
      state.visibleCount = PAGE_SIZE;
      state.bookmarksOnly = false;
      state.activeSource = "all";
      state.activeCategory = "all";
      state.searchIndex = -1;
      els.clearSearch.hidden = !state.query;
      renderTabs();
      renderCategories();
      renderSources();
      renderFeed();
      updateNavActive("feed");
      if (state.query) renderSearchPopover();
      else openSearch();
    });
    els.clearSearch.addEventListener("click", () => {
      state.query = "";
      els.searchInput.value = "";
      els.clearSearch.hidden = true;
      state.visibleCount = PAGE_SIZE;
      renderCategories();
      renderFeed();
      openSearch();
      els.searchInput.focus();
    });

    els.searchInput.addEventListener("keydown", (event) => {
      const suggestions = $$(".suggestion", els.searchPopover);
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        if (!suggestions.length) return;
        event.preventDefault();
        state.searchIndex =
          event.key === "ArrowDown"
            ? (state.searchIndex + 1) % suggestions.length
            : (state.searchIndex - 1 + suggestions.length) % suggestions.length;
        suggestions.forEach((button, index) =>
          button.classList.toggle("is-focused", index === state.searchIndex)
        );
        suggestions[state.searchIndex]?.scrollIntoView({ block: "nearest" });
      }
      if (event.key === "Enter" && suggestions.length) {
        event.preventDefault();
        const target =
          suggestions[Math.max(0, state.searchIndex)] || suggestions[0];
        openDrawer(target.dataset.openItem);
        closeSearch();
      }
      if (event.key === "Escape") {
        closeSearch();
        els.searchInput.blur();
      }
    });

    els.sourceTabs.addEventListener("click", (event) => {
      const tab = event.target.closest("[data-source-tab]");
      if (!tab) return;
      setSource(tab.dataset.sourceTab);
    });

    els.categoryChips.addEventListener("click", (event) => {
      const chip = event.target.closest("[data-category]");
      if (chip) setCategory(chip.dataset.category);
    });

    els.sourceList.addEventListener("click", (event) => {
      const item = event.target.closest("[data-source-filter]");
      if (item) setSource(item.dataset.sourceFilter);
    });

    $$("[data-sort]").forEach((button) => {
      button.addEventListener("click", () => {
        state.sort = button.dataset.sort;
        state.visibleCount = PAGE_SIZE;
        $$("[data-sort]").forEach((item) =>
          item.classList.toggle("is-active", item === button)
        );
        renderFeed();
      });
    });

    els.loadMore.addEventListener("click", () => {
      state.visibleCount += 10;
      renderFeed();
    });

    els.resetFilters.addEventListener("click", () => {
      resetView();
      renderTabs();
      renderCategories();
      renderSources();
      renderFeed();
      updateNavActive("feed");
    });

    els.feedList.addEventListener("keydown", (event) => {
      if ((event.key === "Enter" || event.key === " ") && event.target.classList.contains("feed-item")) {
        event.preventDefault();
        openDrawer(event.target.dataset.openItem);
      }
    });

    $$("[data-nav]").forEach((link) => {
      link.addEventListener("click", (event) => {
        event.preventDefault();
        handleNav(link.dataset.nav);
      });
    });

    $$("[data-about]").forEach((button) => {
      button.addEventListener("click", openAbout);
    });

    els.notifyBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleNotifications();
    });
    els.notifyGoFeed.addEventListener("click", () => {
      closeNotifications();
      handleNav("feed");
    });

    els.drawerClose.addEventListener("click", closeDrawer);
    els.drawerBackdrop.addEventListener("click", closeDrawer);
    els.aboutClose.addEventListener("click", closeAbout);
    els.aboutBackdrop.addEventListener("click", (event) => {
      if (event.target === els.aboutBackdrop) closeAbout();
    });
    els.logoutButton.addEventListener("click", logout);

    // Global delegated clicks.
    document.addEventListener("click", (event) => {
      const bookmark = event.target.closest("[data-bookmark]");
      if (bookmark) {
        event.preventDefault();
        event.stopPropagation();
        toggleBookmark(bookmark.dataset.bookmark);
        return;
      }
      const copy = event.target.closest("[data-copy-link]");
      if (copy) {
        event.preventDefault();
        copyLink(copy.dataset.copyLink);
        return;
      }
      const share = event.target.closest("[data-share]");
      if (share) {
        event.preventDefault();
        shareItem(share.dataset.share);
        return;
      }
      const retry = event.target.closest("[data-retry]");
      if (retry) {
        event.preventDefault();
        loadData(true);
        return;
      }
      const open = event.target.closest("[data-open-item]");
      if (open && !event.target.closest("a[href]")) {
        event.preventDefault();
        closeSearch();
        closeNotifications();
        openDrawer(open.dataset.openItem);
        return;
      }
      if (!els.searchWrap.contains(event.target)) closeSearch();
      if (!els.notifyPopover.contains(event.target) && !els.notifyBtn.contains(event.target)) {
        closeNotifications();
      }
    });

    document.addEventListener("keydown", (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        focusSearch();
        return;
      }
      if (event.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "")) {
        event.preventDefault();
        focusSearch();
        return;
      }
      if (event.key !== "Escape") return;
      if (!els.aboutBackdrop.hidden) {
        closeAbout();
        return;
      }
      if (!els.detailDrawer.hidden) {
        closeDrawer();
        return;
      }
      if (!els.notifyPopover.hidden) {
        closeNotifications();
        return;
      }
      closeSearch();
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth > 820) closeNotifications();
    });
  }

  /* =========================================================
     Init
     ========================================================= */

  function collectElements() {
    Object.assign(els, {
      todayLabel: $("#todayLabel"),
      heroCard: $("#heroCard"),
      heroSide: $("#heroSide"),
      refreshBtn: $("#refreshBtn"),
      sourceHealth: $("#sourceHealth"),
      sourceList: $("#sourceList"),
      navTopicCount: $("#navTopicCount"),
      navBookmarkCount: $("#navBookmarkCount"),
      mobileBookmarkCount: $("#mobileBookmarkCount"),
      sourceTabs: $("#sourceTabs"),
      categoryChips: $("#categoryChips"),
      resultMeta: $("#resultMeta"),
      feedSection: $("#feedSection"),
      feedTitle: $("#feedTitle"),
      feedHeadCount: $("#feedHeadCount"),
      feedList: $("#feedList"),
      feedFoot: $(".feed-foot"),
      loadMore: $("#loadMore"),
      emptyState: $("#emptyState"),
      resetFilters: $("#resetFilters"),
      lastUpdated: $("#lastUpdated"),
      platformBars: $("#platformBars"),
      liveSourceTag: $("#liveSourceTag"),
      categoryDonut: $("#categoryDonut"),
      donutTotal: $("#donutTotal"),
      categoryLegend: $("#categoryLegend"),
      insightText: $("#insightText"),
      crossTag: $("#crossTag"),
      resonanceList: $("#resonanceList"),
      searchWrap: $("#searchWrap"),
      searchInput: $("#searchInput"),
      searchPopover: $("#searchPopover"),
      searchPopoverTitle: $("#searchPopoverTitle"),
      searchResultCount: $("#searchResultCount"),
      searchSuggestions: $("#searchSuggestions"),
      clearSearch: $("#clearSearch"),
      notifyBtn: $("#notifyBtn"),
      notifyPopover: $("#notifyPopover"),
      notifyList: $("#notifyList"),
      notifyTime: $("#notifyTime"),
      notifyGoFeed: $("#notifyGoFeed"),
      detailDrawer: $("#detailDrawer"),
      drawerBackdrop: $("#drawerBackdrop"),
      drawerClose: $("#drawerClose"),
      drawerContent: $("#drawerContent"),
      aboutBackdrop: $("#aboutBackdrop"),
      aboutClose: $("#aboutClose"),
      aboutSources: $("#aboutSources"),
      sessionName: $("#sessionName"),
      logoutButton: $("#logoutButton"),
      toast: $("#toast"),
      toastText: $("#toastText"),
    });
  }

  function init() {
    collectElements();
    bindEvents();
    tickDateLabel();
    syncBookmarkUI();
    loadSession();
    loadData(false);
    window.setInterval(tickDateLabel, 60_000);
    window.setInterval(tickTimeLabels, 30_000);
    window.setInterval(() => loadData(false), 300_000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
