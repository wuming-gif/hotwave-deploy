@echo off
setlocal
cd /d "%~dp0"

set "LAN=0"
set "PORT=8765"
if /I "%~1"=="lan" (
  set "LAN=1"
  if not "%~2"=="" set "PORT=%~2"
) else (
  if not "%~1"=="" set "PORT=%~1"
)

set "HOST=127.0.0.1"
if "%LAN%"=="1" set "HOST=0.0.0.0"

echo ============================================================
echo   Hotwave - realtime trending topics
echo   Local: http://127.0.0.1:%PORT%
if "%LAN%"=="1" echo   LAN mode: share the address printed below
if "%LAN%"=="1" echo   Same Wi-Fi only. Allow TCP %PORT% in Windows Firewall if needed.
echo ============================================================

set "BUNDLED=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if exist "%BUNDLED%" goto :run_bundled

set "PYTHON="
for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PYTHON=%%P"
if defined PYTHON goto :run_python

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto :end
)

echo.
echo Python 3.10+ was not found. Install Python and try again.
pause
exit /b 1

:run_bundled
"%BUNDLED%" app.py
goto :end

:run_python
"%PYTHON%" app.py
goto :end

:end
if errorlevel 1 pause
endlocal