# 沸点 Hotwave · 全网热点雷达

从零实现的中文热点聚合与搜索站点。把微博、抖音、百度、今日头条、B 站五个平台的公开热榜整理成一张统一的信息桌面，支持搜索、分类筛选、跨平台共振识别和个人关注。

站点默认**邀请制**：没有邀请码，即使拿到网址也看不到榜单数据。

![沸点界面预览](preview.png)

## 功能

- **邀请制访问**：签名邀请链接 + HttpOnly 会话 Cookie，支持单独撤销和有效期。
- **实时聚合**：服务端并发抓取 5 个公开热榜，统一排序并合并同名话题。
- **全网搜索**：`Ctrl` / `Cmd` + `K` 唤起搜索，结果即时过滤主榜单；顶栏搜索结果支持键盘上下选择。
- **平台与分类筛选**：综合 / 微博 / 抖音 / 百度 / 头条 / B 站，按要闻、社会、科技、财经、文娱、体育、国际、生活分类。
- **跨平台共振**：识别同一话题在多个平台同时上榜，并在榜单、侧栏与详情中标注。
- **话题详情抽屉**：查看各平台排名、来源读数和来源链接，支持复制链接、系统分享。
- **我的关注**：收藏保存在浏览器 `localStorage`，刷新后仍在。
- **数据状态透明**：接口不可用时自动回落到本地缓存样本，并在侧栏与“数据说明”中标记在线 / 缓存状态。
- **响应式界面**：桌面三栏、平板双栏、手机底部导航；支持键盘操作与减少动效偏好。

## 快速开始

要求：Python 3.10+。项目只使用 Python 标准库，无需安装依赖。

```powershell
# 推荐：双击或在终端运行
.\start.cmd

# 如果 PowerShell 执行策略允许，也可以用脚本
.\start.ps1

# 或者直接运行
python app.py
```

打开 <http://127.0.0.1:8765>，第一次会进入邀请登录页。

先生成一条属于你自己的邀请：

```powershell
python invite.py create --name "我自己" --days 30
```

复制输出中的邀请链接，在浏览器打开并点击“进入沸点”即可。登录状态会保存在当前浏览器。

如果只是想本地预览、不需要邀请，可以临时关闭鉴权：

```powershell
$env:HOTWAVE_AUTH = "off"
python app.py
```

指定端口：

```powershell
$env:PORT = "9000"
python app.py
```

批处理启动脚本也可以传端口：

```bat
start.cmd 9000
```

> 如果 PowerShell 提示“禁止运行脚本”，请直接使用 `start.cmd`，它不受执行策略限制。

## 邀请管理

```powershell
# 创建邀请，默认 14 天
python invite.py create --name "小林" --days 14

# 指定公网域名，生成可直接发送的链接
python invite.py create --name "阿杰" --days 30 --base-url https://hotwave.example.com

# 查看已发出的邀请
python invite.py list

# 撤销某条邀请（使用 create/list 输出里的撤销ID）
python invite.py revoke 4f2a1b9c8d7e
```

- 邀请是**签名 bearer 链接**：拿到链接的人都能使用，所以请一对一发送；如果链接泄露，直接撤销。
- `create` 会同时输出短链接 `/i/<撤销ID>` 和完整签名链接。短链接依赖本地邀请记录，适合固定运行的本机；部署到临时文件系统时请使用完整链接。
- 登录会话有效期取“7 天”和“邀请剩余有效期”中较短的那个。
- 被撤销后，已登录的会话在下一次请求时失效。
- 生产环境必须设置稳定的 `HOTWAVE_SECRET`（至少 24 个字符）。本地未设置时，会生成 `data/auth_secret`。
- 邀请和管理记录分别保存在 `data/invites_issued.json`、`data/invites_revoked.json`，均不会提交到公开仓库。

## 让朋友访问

### 同一 Wi-Fi

```bat
start.cmd lan
```

启动后会打印：

```text
Local: http://127.0.0.1:8765
LAN access (devices on the same Wi-Fi):
  http://192.168.1.23:8765
```

然后用局域网地址生成邀请，确保链接直接指向你能被朋友访问的地址：

```powershell
python invite.py create --name "小林" --days 7 --base-url http://192.168.1.23:8765
```

把生成的邀请链接发给朋友。还需要：

1. 朋友和你在同一个 Wi-Fi / 局域网；
2. Windows 防火墙允许 Python 或 TCP 端口 `8765` 的入站访问；
3. 路由器没有开启“访客网络隔离 / AP 隔离”。

如果地址是 `10.x` 或 `172.x`，通常意味着你处在校园网或单位网络，管理员可能禁止设备互访。这种情况下优先使用 Tailscale 或手机热点。

换端口：

```bat
start.cmd lan 8766
```

PowerShell 版本：

```powershell
.\start.ps1 -Lan -Port 8766
```

### 临时公网地址

不需要域名和服务器，电脑开着就能用。任选一种：

**开箱即用（OpenSSH）**

```powershell
ssh -T -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -R 80:127.0.0.1:8765 nokey@localhost.run
```

命令会打印一个 `https://xxxx.lhr.life` 地址，再生成邀请：

```powershell
python invite.py create --name "朋友" --days 7 --base-url https://xxxx.lhr.life
```

**Cloudflare Tunnel**

安装 `cloudflared` 后：

```powershell
cloudflared tunnel --url http://127.0.0.1:8765
```

记下输出的 `https://xxxx.trycloudflare.com` 地址，生成邀请时把它作为 `--base-url`。

隧道关闭、电脑睡眠或 SSH 断开后链接会失效；临时域名每次重启都会变化，需要重新生成邀请。临时隧道服务能看到经过的流量，只适合公开榜单数据，不要用来传输敏感内容。

### Tailscale 私有网络

你和朋友都安装 Tailscale 并加入同一个 tailnet，然后以局域网模式启动。朋友访问 `http://<你的 Tailscale IP>:8765`，再使用你生成的邀请链接登录。适合只给熟人使用，不直接暴露公网。

## 免费部署

项目已经包含 `render.yaml`、`Dockerfile` 和空依赖的 `requirements.txt`，可直接部署到支持 Python 的免费平台。

### Render

1. 把项目推到 GitHub；
2. 在 Render 中新建 Blueprint，选择该仓库，它会读取 `render.yaml`；
3. 部署完成后，在 Render 环境变量里复制 `HOTWAVE_SECRET` 的值；
4. 在本地使用同一个 secret 生成邀请：

```powershell
$env:HOTWAVE_SECRET = "把 Render 里的值粘贴到这里"
python invite.py create --name "朋友" --days 30 --base-url https://你的服务.onrender.com
```

注意事项：

- Render 免费实例长时间无访问会休眠，首次打开较慢。
- 免费实例文件系统是临时的，因此**不要依赖本地文件保存会话和撤销记录**；必须设置固定的 `HOTWAVE_SECRET`。需要长期撤销列表时，把撤销 ID 写进 `HOTWAVE_REVOKED_INVITES` 环境变量。
- 从海外机房抓取国内热榜可能被限流，届时页面会显示缓存样本和“缓存”状态。
- 正式使用建议绑定自定义域名并开启 HTTPS。

### Docker / 云服务器

```powershell
docker build -t hotwave .
docker run -d --name hotwave -p 8765:8765 `
  -e HOTWAVE_SECRET="至少24位的随机字符串" `
  -e HOTWAVE_PUBLIC_URL="https://你的域名" `
  hotwave
```

云服务器上也可以直接：

```bash
HOST=0.0.0.0 PORT=8765 HOTWAVE_SECRET="..." python app.py
```

前面加 Nginx/Caddy 反向代理并启用 HTTPS。部署后必须保留 `HOTWAVE_SECRET`，否则重启会使所有邀请和登录失效。

## 项目结构

```text
.
├─ app.py                 # 聚合服务 + 鉴权 + 静态文件服务
├─ auth.py                # 签名邀请、会话 Cookie、撤销
├─ invite.py              # 邀请管理命令行
├─ data/
│  └─ fallback.json       # 数据源不可用时的缓存样本
├─ public/
│  ├─ index.html          # 主页面
│  ├─ styles.css          # 视觉系统与响应式布局
│  ├─ app.js              # 搜索、筛选、图表、抽屉、关注逻辑
│  ├─ login.html          # 邀请登录页
│  ├─ login.css
│  ├─ login.js
│  └─ favicon.svg
├─ Dockerfile
├─ render.yaml
├─ requirements.txt
├─ start.cmd              # Windows 一键启动（推荐）
├─ start.ps1              # PowerShell 启动脚本
├─ preview.png
└─ README.md
```

## 数据与算法

数据来自各平台公开页面接口：

| 平台 | 榜单 | 标识 |
| --- | --- | --- |
| 微博 | 实时热搜 | 微博指数 |
| 抖音 | 抖音热榜 | 热榜热度值 |
| 百度 | 实时热点 | 榜单名次 |
| 今日头条 | 头条热榜 | 热度值 |
| B 站 | 全站热门 | 播放量 |

服务端每 3 分钟缓存一次聚合结果；点击“刷新”会强制拉取。

- 热度指数为 **站内归一化指标**：按榜单名次映射到 0–100，并结合原始读数做小幅修正，同一话题多平台出现时增加共振权重。它不是任何平台的官方指数。
- 同名话题按标题规范化后合并，保留各平台名次与原始读数。
- 抓取失败时使用 `data/fallback.json` 的样本数据，并在 `sources.status` 中标记为 `cached`。
- 排名变化（`rankChange`）从第二次成功抓取开始计算；首次启动时显示为空白，不会伪造涨跌。

## 接口

除 `/api/health` 和登录接口外，所有页面和 API 都需要有效会话 Cookie。

### `GET /api/hot`

返回聚合后的完整数据。

- `?refresh=1`：跳过 3 分钟缓存，强制刷新。
- `sources`：五个平台的在线状态、延迟和条目数。
- `items`：合并去重后的热点，包含 `platforms` 数组。
- `stats`：总热度、在榜话题数、跨平台数量、分类分布。
- `generatedAt`：本次数据生成时间（ISO 8601，含时区）。

### 鉴权接口

- `POST /api/auth/login`：请求体 `{"invite":"...","next":"/"}`，成功后设置 HttpOnly Cookie。
- `GET /api/auth/me`：返回当前邀请姓名、邀请 ID 和过期时间。
- `POST /api/auth/logout`：退出当前浏览器会话。
- `GET /api/health`：公开健康检查，可用于托管平台探活。

## 交互快捷键

| 快捷键 | 作用 |
| --- | --- |
| `Ctrl` / `Cmd` + `K` | 聚焦全网搜索 |
| `/` | 聚焦搜索（输入框外） |
| `↑` / `↓` | 在搜索结果中移动 |
| `Enter` | 打开当前搜索结果 |
| `Esc` | 关闭搜索、通知、详情或弹层 |

退出当前邀请：打开页面底部“数据说明”弹层，点击“退出邀请”。

## 说明

- 邀请链接是 bearer 凭证，不是实名身份认证；拿到链接的人可以访问，也可以转发。需要严格身份控制时，请使用 Cloudflare Access 邮箱白名单或接入 OAuth。
- 公开热榜接口可能随平台策略调整、限流或失效；服务端已做超时、并发隔离与缓存回落，但生产部署建议增加持久化缓存、代理池和监控。
- 本站仅做公开信息聚合，不存储用户账号数据；关注列表只保存在当前浏览器。
- 页面无外部字体、CDN 或前端依赖，离线时除实时数据外样式与交互完整可用。
