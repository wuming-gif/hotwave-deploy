#!/usr/bin/env python3
"""Admin CLI for Hotwave invitations.

Examples:
  python invite.py create --name "小林" --days 14
  python invite.py create --name "阿杰" --days 30 --base-url https://hotwave.example.com
  python invite.py list
  python invite.py revoke 4f2a1b9c8d7e
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Any

import auth


def _json_out(payload: Any) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def command_create(args: argparse.Namespace) -> int:
    record = auth.create_invite(args.name, days=args.days, base_url=args.base_url)
    if args.json:
        _json_out(record)
        return 0
    print("邀请已创建")
    print(f"  姓名:   {record['name']}")
    print(f"  撤销ID: {record['jti']}")
    print(f"  有效期: 至 {auth.format_timestamp(record['expiresAt'])}")
    print()
    print("短链接（推荐发给朋友）:")
    print(record["shortUrl"])
    print()
    print("完整邀请链接（备用）:")
    print(record["url"])
    return 0


def command_list(args: argparse.Namespace) -> int:
    records = auth.load_issued()
    revoked = auth.load_revoked()
    now = int(time.time())
    rows = []
    for record in records:
        status = "已撤销" if record["jti"] in revoked else "已过期" if record["expiresAt"] <= now else "有效"
        rows.append(
            {
                "jti": record["jti"],
                "name": record["name"],
                "createdAt": record["createdAt"],
                "expiresAt": record["expiresAt"],
                "status": status,
            }
        )
    if args.json:
        _json_out(rows)
        return 0
    if not rows:
        print("还没有发出过邀请。")
        return 0
    print(f"{'姓名':<12} {'状态':<6} {'有效期至':<18} 撤销ID")
    print("-" * 66)
    for row in rows:
        print(
            f"{row['name']:<12} {row['status']:<6} "
            f"{auth.format_timestamp(row['expiresAt']):<18} {row['jti']}"
        )
    return 0


def command_revoke(args: argparse.Namespace) -> int:
    auth.revoke(args.invite_id)
    if args.json:
        _json_out({"ok": True, "revoked": args.invite_id})
    else:
        print(f"已撤销邀请: {args.invite_id}")
        print("已登录的会话会在下一次请求时失效。")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="沸点 Hotwave 邀请管理")
    subparsers = parser.add_subparsers(dest="command", required=True)

    create = subparsers.add_parser("create", help="创建一条邀请链接")
    create.add_argument("--name", required=True, help="邀请对象的名字，例如：小林")
    create.add_argument("--days", type=int, default=auth.DEFAULT_INVITE_DAYS, help="有效天数")
    create.add_argument("--base-url", help="站点公网地址，例如 https://hotwave.example.com")
    create.add_argument("--json", action="store_true", help="输出 JSON，便于脚本调用")
    create.set_defaults(handler=command_create)

    listing = subparsers.add_parser("list", help="查看已发出的邀请")
    listing.add_argument("--json", action="store_true")
    listing.set_defaults(handler=command_list)

    revoke = subparsers.add_parser("revoke", help="撤销某条邀请")
    revoke.add_argument("invite_id", help="创建邀请时打印的撤销ID")
    revoke.add_argument("--json", action="store_true")
    revoke.set_defaults(handler=command_revoke)

    return parser


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    parser = build_parser()
    args = parser.parse_args()
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
