#!/usr/bin/env python3
"""沸点 Hotwave - a dependency-free realtime hot-topic radar.

The server aggregates public hot lists from several Chinese platforms,
normalises them into one feed, and serves the static front-end.
"""

from __future__ import annotations

import hashlib
import json
import math
import mimetypes
import os
import re
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

import auth

ROOT = Path(__file__).resolve().parent
PUBLIC_DIR = ROOT / "public"
FALLBACK_FILE = ROOT / "data" / "fallback.json"
LOGIN_FILE = PUBLIC_DIR / "login.html"
CACHE_TTL = 180
PORT = int(os.environ.get("PORT", "8765"))
HOST = os.environ.get("HOST", "127.0.0.1")
AUTH_ENABLED = os.environ.get("HOTWAVE_AUTH", "invite").strip().lower() not in {
    "off",
    "0",
    "false",
    "none",
}
LOGIN_ASSETS = {"/login.css", "/login.js"}
PUBLIC_ASSETS = {"/favicon.svg"}

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36"
)

SOURCES: list[dict[str, Any]] = [
    {
        "id": "weibo",
        "name": "微博",
        "short": "微",
        "color": "#ff5a3c",
        "description": "微博实时热搜",
    },
    {
        "id": "douyin",
        "name": "抖音",
        "short": "抖",
        "color": "#171614",
        "description": "抖音热榜",
    },
    {
        "id": "baidu",
        "name": "百度",
        "short": "百",
        "color": "#4269f5",
        "description": "百度实时热点",
    },
    {
        "id": "toutiao",
        "name": "头条",
        "short": "头",
        "color": "#f0413c",
        "description": "今日头条热榜",
    },
    {
        "id": "bilibili",
        "name": "B站",
        "short": "B",
        "color": "#00a1d6",
        "description": "B站热门视频",
    },
]

SOURCE_BY_ID = {source["id"]: source for source in SOURCES}

CATEGORY_META = {
    "要闻": {"color": "#d14b2b", "soft": "#fdebe5"},
    "社会": {"color": "#8a6a1f", "soft": "#f8f0d8"},
    "科技": {"color": "#166a62", "soft": "#e3f4f1"},
    "财经": {"color": "#245c9c", "soft": "#e8f0fa"},
    "文娱": {"color": "#a33b68", "soft": "#f9e9f0"},
    "体育": {"color": "#3d6b2b", "soft": "#eaf3e4"},
    "国际": {"color": "#6750a4", "soft": "#f0ecfa"},
    "生活": {"color": "#b4612c", "soft": "#fbeee4"},
    "其他": {"color": "#736d63", "soft": "#f0ede7"},
}

CATEGORY_RULES: list[tuple[str, tuple[str, ...]]] = [
    (
        "体育",
        (
            "比赛", "国足", "足球", "篮球", "NBA", "CBA", "世界杯", "全运会",
            "奥运", "冠军", "队员", "教练", "乒乓球", "网球", "联赛", "金牌",
            "田径", "游泳", "羽毛球", "女排", "男足", "女足", "球迷", "赛场",
        ),
    ),
    (
        "国际",
        (
            "美国", "日本", "俄罗斯", "乌克兰", "特朗普", "联合国", "以色列",
            "伊朗", "欧洲", "法国", "德国", "英国", "韩国", "朝鲜", "加沙",
            "中东", "总统", "总理", "外交部", "大使", "欧盟", "白宫", "海外",
            "菲律宾", "南海", "台海", "军机",
        ),
    ),
    (
        "要闻",
        (
            "全会", "中央", "国务院", "主席", "总书记", "会议", "政策", "发布会",
            "十五五", "规划", "政府", "人大", "政协", "党建", "党员", "国家",
            "教育部", "发改委", "民生", "改革", "重要", "开幕", "闭幕", "新规",
            "解放军",
        ),
    ),
    (
        "财经",
        (
            "股市", "A股", "证监会", "基金", "银行", "经济", "房价", "楼市",
            "黄金", "降息", "利率", "人民币", "关税", "市值", "上市", "央行",
            "消费", "双十一", "理财", "营收", "销量", "财报", "金融", "物价",
            "就业", "工资", "养老金", "医保", "社保", "存款", "贷款",
        ),
    ),
    (
        "科技",
        (
            "手机", "芯片", "AI", "人工智能", "苹果", "华为", "小米", "特斯拉",
            "机器人", "互联网", "微信", "支付宝", "京东", "阿里", "字节", "模型",
            "数据", "航天", "卫星", "量子", "6G", "操作系统", "电脑", "显卡",
            "无人机", "新能源", "自动驾驶", "低空经济", "算法", "开源", "科技",
            "神舟", "火箭", "空间站", "电池", "半导体", "智能", "数码",
        ),
    ),
    (
        "文娱",
        (
            "综艺", "决赛", "明星", "演唱会", "电影", "电视剧", "剧集", "演员",
            "歌手", "官宣", "恋情", "结婚", "离婚", "造型", "红毯", "喜剧",
            "音乐", "热播", "角色", "网红", "直播", "导演", "票房", "动画",
            "游戏", "电竞", "文娱", "舞台", "妆", "短片", "纪录片", "UP主",
            "娱乐", "获奖", "定档", "预告", "歌曲", "乐队", "偶像", "披荆斩棘",
            "乘风破浪", "总决赛", "成团", "选秀", "LGD", "EDGM", "KPL", "LPL",
            "战队", "王者荣耀", "英雄联盟",
        ),
    ),
    (
        "社会",
        (
            "新闻", "警方", "医院", "学校", "教师", "学生", "天气", "台风",
            "暴雨", "交通", "事故", "火灾", "失联", "救援", "法院", "判刑",
            "诈骗", "老人", "儿童", "女子", "男子", "官方", "通报", "回应",
            "涨价", "放假", "国庆", "春节", "考研", "高考", "旅游", "景区",
            "社区", "食堂", "高校", "大学", "宿舍", "博物馆", "非遗", "降温",
        ),
    ),
]

CATEGORY_ORDER = ("要闻", "社会", "科技", "财经", "文娱", "体育", "国际", "生活", "其他")

SOURCE_RANK_WEIGHT = {
    "weibo": 0.0,
    "douyin": 0.55,
    "baidu": -1.0,
    "toutiao": 0.2,
    "bilibili": -2.2,
}

_BAD_TITLE_RE = re.compile(r"[\u200b\u200c\u200d\ufeff]")
_HASH_RE = re.compile(r"^[#＃\s]+|[#＃\s]+$")
_SPACE_RE = re.compile(r"\s+")
_NORM_RE = re.compile(r"[^\w\u4e00-\u9fff]+", re.UNICODE)


def clean_title(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    title = _BAD_TITLE_RE.sub("", value)
    title = _HASH_RE.sub("", title)
    title = _SPACE_RE.sub(" ", title).strip()
    return title


def normalise_title(value: str) -> str:
    return _NORM_RE.sub("", value.lower())


def classify(title: str, source_id: str, source_category: str = "") -> str:
    if source_id == "bilibili":
        mapping = {
            "科技": "科技",
            "知识": "科技",
            "财经": "财经",
            "体育": "体育",
            "影视": "文娱",
            "娱乐": "文娱",
            "音乐": "文娱",
            "动画": "文娱",
            "游戏": "文娱",
            "鬼畜": "文娱",
            "舞蹈": "文娱",
            "生活": "社会",
            "资讯": "要闻",
            "纪录片": "文娱",
        }
        if source_category in mapping:
            return mapping[source_category]

    haystack = f"{title} {source_category}".upper()
    for category, rules in CATEGORY_RULES:
        for word in rules:
            if word.upper() in haystack:
                return category
    if source_id == "douyin":
        return "生活"
    if source_id == "bilibili":
        return "文娱"
    return "社会"


def fetch_json(url: str, referer: str) -> Any:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": UA,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
            "Referer": referer,
            "Connection": "close",
        },
    )
    with urllib.request.urlopen(request, timeout=13) as response:
        body = response.read()
    return json.loads(body.decode("utf-8", errors="replace"))


def source_weibo() -> list[dict[str, Any]]:
    payload = fetch_json(
        "https://weibo.com/ajax/side/hotSearch",
        "https://weibo.com/",
    )
    rows = payload.get("data", {}).get("realtime", [])
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[:50]):
        title = clean_title(row.get("word") or row.get("note"))
        if not title:
            continue
        rank = int(row.get("realpos") or index + 1)
        topic_flag = bool(row.get("topic_flag"))
        query = f"#{title}#" if topic_flag else title
        label = clean_title(row.get("label_name") or row.get("icon_desc"))
        result.append(
            {
                "title": title,
                "url": "https://s.weibo.com/weibo?q=" + urllib.parse.quote(query),
                "rank": rank,
                "raw": int(row.get("num") or 0),
                "label": label,
                "sourceCategory": clean_title(row.get("flag_desc")),
            }
        )
    return result


def source_douyin() -> list[dict[str, Any]]:
    payload = fetch_json(
        "https://www.douyin.com/aweme/v1/web/hot/search/list/"
        "?device_platform=webapp&aid=6383&channel=channel_pc_web&detail_list=1",
        "https://www.douyin.com/",
    )
    rows = payload.get("data", {}).get("word_list", [])
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[:50]):
        title = clean_title(row.get("word"))
        if not title:
            continue
        rank = int(row.get("position") or index + 1)
        sentence_id = row.get("sentence_id")
        url = (
            f"https://www.douyin.com/hot/{sentence_id}"
            if sentence_id
            else "https://www.douyin.com/hot"
        )
        label_code = row.get("label")
        label = ""
        if rank <= 3:
            label = "热"
        elif label_code in (1, 2):
            label = "新"
        result.append(
            {
                "title": title,
                "url": url,
                "rank": rank,
                "raw": int(row.get("hot_value") or 0),
                "label": label,
                "sourceCategory": "",
            }
        )
    return result


def source_baidu() -> list[dict[str, Any]]:
    payload = fetch_json(
        "https://top.baidu.com/api/board?platform=wise&tab=realtime",
        "https://top.baidu.com/board?tab=realtime",
    )
    cards = payload.get("data", {}).get("cards", [])
    item_container = next(
        (card for card in cards if card.get("component") == "tabTextList"),
        None,
    )
    if not item_container:
        return []
    content = item_container.get("content", [])
    rows = content[0].get("content", []) if content else []
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[:50]):
        title = clean_title(row.get("word"))
        if not title:
            continue
        rank = int(row.get("index") or index + 1)
        result.append(
            {
                "title": title,
                "url": row.get("url") or "https://top.baidu.com/board?tab=realtime",
                "rank": rank,
                "raw": 0,
                "label": clean_title(row.get("labelTagName")),
                "sourceCategory": "",
            }
        )
    return result


def source_toutiao() -> list[dict[str, Any]]:
    payload = fetch_json(
        "https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc",
        "https://www.toutiao.com/",
    )
    rows = payload.get("data", [])
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[:50]):
        title = clean_title(row.get("Title") or row.get("title"))
        if not title:
            continue
        label = "热" if row.get("Label") == "hot" else clean_title(row.get("Label"))
        result.append(
            {
                "title": title,
                "url": row.get("Url") or row.get("url") or "https://www.toutiao.com/",
                "rank": index + 1,
                "raw": int(float(row.get("HotValue") or 0)),
                "label": label,
                "sourceCategory": "",
            }
        )
    return result


def source_bilibili() -> list[dict[str, Any]]:
    payload = fetch_json(
        "https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&type=all",
        "https://www.bilibili.com/ranking/",
    )
    rows = payload.get("data", {}).get("list", [])
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[:50]):
        title = clean_title(row.get("title"))
        if not title:
            continue
        bvid = row.get("bvid")
        url = f"https://www.bilibili.com/video/{bvid}" if bvid else "https://www.bilibili.com/"
        stat = row.get("stat") or {}
        result.append(
            {
                "title": title,
                "url": url,
                "rank": index + 1,
                "raw": int(stat.get("view") or 0),
                "label": "",
                "sourceCategory": clean_title(row.get("tname")),
            }
        )
    return result


FETCHERS: dict[str, Callable[[], list[dict[str, Any]]]] = {
    "weibo": source_weibo,
    "douyin": source_douyin,
    "baidu": source_baidu,
    "toutiao": source_toutiao,
    "bilibili": source_bilibili,
}


def compact_number(value: float) -> str:
    if value >= 100_000_000:
        return f"{value / 100_000_000:.2f}亿"
    if value >= 10_000:
        return f"{value / 10_000:.1f}万"
    if value > 0:
        return f"{int(value):,}"
    return "—"


def score_for(rank: int, raw: int, source_id: str) -> float:
    base = max(32.0, 96.6 - (rank - 1) * 1.28)
    adjust = SOURCE_RANK_WEIGHT.get(source_id, 0.0)
    raw_boost = 0.0
    if raw > 0:
        raw_boost = min(1.1, max(0.0, (math.log10(max(raw, 1)) - 4.0) * 0.35))
    return round(min(99.9, base + adjust + raw_boost), 1)


def base_item(raw: dict[str, Any], source_id: str) -> dict[str, Any]:
    source = SOURCE_BY_ID[source_id]
    title = raw["title"]
    rank = int(raw.get("rank") or 1)
    raw_hot = int(raw.get("raw") or 0)
    score = score_for(rank, raw_hot, source_id)
    category = classify(title, source_id, str(raw.get("sourceCategory") or ""))
    digest = hashlib.sha1(f"{source_id}:{title}".encode("utf-8")).hexdigest()[:12]
    if raw_hot > 0:
        heat_text = compact_number(raw_hot)
        if source_id == "bilibili":
            heat_text += " 播放"
    else:
        heat_text = f"第 {rank} 名"
    platform = {
        "source": source_id,
        "name": source["name"],
        "short": source["short"],
        "color": source["color"],
        "rank": rank,
        "raw": raw_hot,
        "heatText": heat_text,
        "score": score,
        "url": raw["url"],
        "label": raw.get("label") or "",
    }
    return {
        "id": digest,
        "title": title,
        "url": raw["url"],
        "source": source_id,
        "sourceName": source["name"],
        "sourceShort": source["short"],
        "sourceColor": source["color"],
        "rank": rank,
        "rawHot": raw_hot,
        "heatText": heat_text,
        "heat": score,
        "category": category,
        "label": raw.get("label") or "",
        "platforms": [platform],
        "platformCount": 1,
        "isNew": False,
        "rankChange": 0,
    }


def merge_items(raw_by_source: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for source_id, rows in raw_by_source.items():
        for raw in rows:
            item = base_item(raw, source_id)
            key = normalise_title(item["title"])
            if not key:
                continue
            if key not in merged:
                merged[key] = item
                continue

            target = merged[key]
            target["platforms"].append(item["platforms"][0])
            # Keep the best-scoring platform's metadata, but retain every appearance.
            if item["heat"] > target["heat"]:
                platforms = target["platforms"]
                for field in (
                    "id", "url", "source", "sourceName", "sourceShort",
                    "sourceColor", "rank", "rawHot", "heatText", "heat", "label",
                ):
                    target[field] = item[field]
                target["platforms"] = platforms

    items = list(merged.values())
    for item in items:
        item["platforms"].sort(key=lambda platform: platform["score"], reverse=True)
        primary = item["platforms"][0]
        item.update(
            {
                "source": primary["source"],
                "sourceName": primary["name"],
                "sourceShort": primary["short"],
                "sourceColor": primary["color"],
                "rank": primary["rank"],
                "rawHot": primary["raw"],
                "heatText": primary["heatText"],
                "url": primary["url"],
            }
        )
        item["platformCount"] = len(item["platforms"])
        item["heat"] = round(
            min(
                99.9,
                max(platform["score"] for platform in item["platforms"])
                + min(7.0, (item["platformCount"] - 1) * 2.8),
            ),
            1,
        )
        item["label"] = next(
            (
                platform.get("label")
                for platform in item["platforms"]
                if platform.get("label")
            ),
            "",
        )
    items.sort(key=lambda item: (-item["heat"], item["rank"]))
    return items


RANK_HISTORY: dict[str, dict[str, int]] = {}
HISTORY_LOCK = threading.Lock()


def annotate_movement(items: list[dict[str, Any]]) -> None:
    with HISTORY_LOCK:
        previous = {source_id: dict(ranks) for source_id, ranks in RANK_HISTORY.items()}
    for item in items:
        changes: list[int] = []
        for platform in item["platforms"]:
            old_rank = previous.get(platform["source"], {}).get(
                normalise_title(item["title"])
            )
            if old_rank:
                changes.append(old_rank - platform["rank"])
        if changes:
            item["rankChange"] = max(changes, key=abs)
            item["isNew"] = False
        elif previous:
            item["rankChange"] = 0
            item["isNew"] = True
        else:
            item["rankChange"] = 0
            item["isNew"] = False


def remember_ranks(
    raw_by_source: dict[str, list[dict[str, Any]]],
    live_ids: set[str],
) -> None:
    with HISTORY_LOCK:
        for source_id, rows in raw_by_source.items():
            if source_id not in live_ids:
                continue
            RANK_HISTORY[source_id] = {
                normalise_title(clean_title(row.get("title"))): int(row.get("rank") or 1)
                for row in rows
            }


def load_fallback() -> dict[str, list[dict[str, Any]]]:
    try:
        payload = json.loads(FALLBACK_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {source["id"]: [] for source in SOURCES}
    result: dict[str, list[dict[str, Any]]] = {}
    for source in SOURCES:
        rows = payload.get(source["id"], [])
        result[source["id"]] = [
            {
                "title": clean_title(row.get("title")),
                "url": row.get("url") or "#",
                "rank": index + 1,
                "raw": int(row.get("raw") or 0),
                "label": "缓存",
                "sourceCategory": "",
            }
            for index, row in enumerate(rows)
            if clean_title(row.get("title"))
        ]
    return result


def build_payload() -> dict[str, Any]:
    started = time.perf_counter()
    raw_by_source: dict[str, list[dict[str, Any]]] = {}
    statuses: list[dict[str, Any]] = []
    fallback = load_fallback()
    live_ids: set[str] = set()

    with ThreadPoolExecutor(max_workers=len(SOURCES)) as pool:
        futures = {
            pool.submit(FETCHERS[source["id"]]): (source, time.perf_counter())
            for source in SOURCES
        }
        for future in as_completed(futures):
            source, submitted = futures[future]
            source_started = time.perf_counter()
            try:
                rows = future.result()
                if not rows:
                    raise ValueError("empty response")
                raw_by_source[source["id"]] = rows
                live_ids.add(source["id"])
                statuses.append(
                    {
                        **source,
                        "status": "live",
                        "count": len(rows),
                        "latency": int((source_started - submitted) * 1000),
                    }
                )
            except Exception as error:  # noqa: BLE001 - source failures are expected
                cached_rows = fallback.get(source["id"], [])
                raw_by_source[source["id"]] = cached_rows
                statuses.append(
                    {
                        **source,
                        "status": "cached" if cached_rows else "offline",
                        "count": len(cached_rows),
                        "latency": int((source_started - submitted) * 1000),
                        "error": type(error).__name__,
                    }
                )

    statuses.sort(key=lambda status: [source["id"] for source in SOURCES].index(status["id"]))
    items = merge_items(raw_by_source)
    annotate_movement(items)
    remember_ranks(raw_by_source, live_ids)

    source_counts: dict[str, int] = {}
    total_raw = 0
    total_heat = 0
    for source_id, rows in raw_by_source.items():
        source_counts[source_id] = len({normalise_title(row["title"]) for row in rows})
        total_raw += len(rows)
        total_heat += sum(int(row.get("raw") or 0) for row in rows)

    cross_platform = sum(1 for item in items if item["platformCount"] > 1)
    category_counts: dict[str, int] = {}
    for item in items:
        category_counts[item["category"]] = category_counts.get(item["category"], 0) + 1
    top_category = max(category_counts, key=category_counts.get) if category_counts else "其他"
    top_source_id = max(source_counts, key=source_counts.get) if source_counts else ""
    top_source_name = SOURCE_BY_ID.get(top_source_id, {}).get("name", "全网")
    live_count = sum(1 for status in statuses if status["status"] == "live")

    if cross_platform:
        insight = (
            f"全网共捕捉到 {len(items)} 个话题，其中 {cross_platform} 个在多个平台同时上榜。"
            f"{top_source_name}贡献了最多的在榜话题，{top_category}是当前最集中的讨论场。"
        )
    else:
        insight = (
            f"全网共捕捉到 {len(items)} 个话题，当前讨论主要集中在{top_category}。"
            f"{top_source_name}的在榜话题数量领先。"
        )

    elapsed_ms = int((time.perf_counter() - started) * 1000)
    generated_at = datetime.now().astimezone().isoformat(timespec="seconds")
    return {
        "ok": True,
        "generatedAt": generated_at,
        "cacheTtl": CACHE_TTL,
        "elapsedMs": elapsed_ms,
        "sources": statuses,
        "items": items,
        "stats": {
            "totalTopics": len(items),
            "totalRaw": total_raw,
            "totalHeat": total_heat,
            "sourceCount": len(SOURCES),
            "liveSources": live_count,
            "crossPlatform": cross_platform,
            "topCategory": top_category,
            "topSource": top_source_name,
            "categoryCounts": category_counts,
            "sourceCounts": source_counts,
        },
        "insight": insight,
        "categoryMeta": CATEGORY_META,
    }


CACHE_LOCK = threading.Lock()
CACHE: dict[str, Any] = {"payload": None, "created": 0.0}


def get_payload(force: bool = False) -> dict[str, Any]:
    now = time.time()
    cached = CACHE.get("payload")
    if cached and not force and now - CACHE["created"] < CACHE_TTL:
        response = dict(cached)
        response["cached"] = True
        response["cacheAge"] = int(now - CACHE["created"])
        return response

    with CACHE_LOCK:
        now = time.time()
        cached = CACHE.get("payload")
        if cached and not force and now - CACHE["created"] < CACHE_TTL:
            response = dict(cached)
            response["cached"] = True
            response["cacheAge"] = int(now - CACHE["created"])
            return response
        payload = build_payload()
        CACHE["payload"] = payload
        CACHE["created"] = time.time()
        response = dict(payload)
        response["cached"] = False
        response["cacheAge"] = 0
        return response


LOGIN_ATTEMPTS: dict[str, list[float]] = {}
LOGIN_ATTEMPTS_LOCK = threading.Lock()
LOGIN_WINDOW_SECONDS = 600
LOGIN_MAX_ATTEMPTS = 12


def login_attempt_allowed(ip: str) -> bool:
    now = time.time()
    with LOGIN_ATTEMPTS_LOCK:
        attempts = [stamp for stamp in LOGIN_ATTEMPTS.get(ip, []) if now - stamp < LOGIN_WINDOW_SECONDS]
        LOGIN_ATTEMPTS[ip] = attempts
        return len(attempts) < LOGIN_MAX_ATTEMPTS


def record_login_attempt(ip: str) -> None:
    with LOGIN_ATTEMPTS_LOCK:
        LOGIN_ATTEMPTS.setdefault(ip, []).append(time.time())


def clear_login_attempts(ip: str) -> None:
    with LOGIN_ATTEMPTS_LOCK:
        LOGIN_ATTEMPTS.pop(ip, None)


class HotwaveHandler(BaseHTTPRequestHandler):
    server_version = "Hotwave/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        message = fmt % args
        message = re.sub(r"(invite=)[^&\s]+", r"\1[redacted]", message)
        print(f"[{self.log_date_time_string()}] {message}")

    def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def client_ip(self) -> str:
        forwarded = self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
        return forwarded or (self.client_address[0] if self.client_address else "unknown")

    def request_is_secure(self) -> bool:
        proto = self.headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower()
        if proto == "https" or self.headers.get("X-Forwarded-Ssl", "").lower() == "on":
            return True
        forwarded = self.headers.get("Forwarded", "").lower()
        if "proto=https" in forwarded:
            return True
        public_url = os.environ.get("HOTWAVE_PUBLIC_URL", "").strip()
        if public_url.startswith("https://"):
            public_host = (urllib.parse.urlparse(public_url).hostname or "").lower()
            request_host = (self.headers.get("Host", "").split(":")[0] or "").lower()
            if public_host and request_host == public_host:
                return True
        return False

    def session_payload(self) -> dict[str, Any] | None:
        if not AUTH_ENABLED:
            return {"sub": "local", "jti": "local"}
        raw_cookie = self.headers.get("Cookie", "")
        if not raw_cookie:
            return None
        cookie = SimpleCookie()
        try:
            cookie.load(raw_cookie)
        except Exception:  # noqa: BLE001 - malformed cookies should fail closed
            return None
        morsel = cookie.get(auth.COOKIE_NAME)
        if not morsel:
            return None
        return auth.verify_session(morsel.value)

    def set_session_cookie(self, token: str, max_age: int) -> None:
        cookie = SimpleCookie()
        cookie[auth.COOKIE_NAME] = token
        morsel = cookie[auth.COOKIE_NAME]
        morsel["path"] = "/"
        morsel["max-age"] = str(max(0, int(max_age)))
        morsel["httponly"] = True
        morsel["samesite"] = "Lax"
        if self.request_is_secure():
            morsel["secure"] = True
        self.send_header("Set-Cookie", morsel.OutputString())

    def clear_session_cookie(self) -> None:
        cookie = SimpleCookie()
        cookie[auth.COOKIE_NAME] = ""
        morsel = cookie[auth.COOKIE_NAME]
        morsel["path"] = "/"
        morsel["max-age"] = "0"
        morsel["httponly"] = True
        morsel["samesite"] = "Lax"
        if self.request_is_secure():
            morsel["secure"] = True
        self.send_header("Set-Cookie", morsel.OutputString())

    def redirect(self, location: str, status: int = HTTPStatus.FOUND) -> None:
        self.send_response(status)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()

    @staticmethod
    def safe_next(value: Any) -> str:
        target = str(value or "/").strip()
        if not target.startswith("/") or target.startswith("//") or "\\" in target:
            return "/"
        if target.startswith("/login"):
            return "/"
        return target[:1000]

    def redirect_to_login(self, path: str, query: str) -> None:
        target = path or "/"
        if query:
            target += "?" + query
        self.redirect("/login?next=" + urllib.parse.quote(target, safe=""))

    def require_session(self, parsed: urllib.parse.ParseResult) -> bool:
        if self.session_payload():
            return True
        if parsed.path.startswith("/api/"):
            next_path = parsed.path + (("?" + parsed.query) if parsed.query else "")
            self.send_json(
                {
                    "ok": False,
                    "authRequired": True,
                    "message": "需要邀请码才能访问",
                    "loginUrl": "/login?next=" + urllib.parse.quote(next_path, safe=""),
                },
                status=HTTPStatus.UNAUTHORIZED,
            )
        else:
            self.redirect_to_login(parsed.path, parsed.query)
        return False

    def handle_short_invite(self, path: str) -> None:
        invite_id = path.removeprefix("/i/").strip("/")
        if not re.fullmatch(r"[0-9a-f]{12}", invite_id):
            self.redirect("/login?expired=1")
            return
        token = auth.find_invite_token(invite_id)
        if token and auth.verify_invite(token):
            self.redirect("/login?invite=" + urllib.parse.quote(token))
        else:
            self.redirect("/login?expired=1")

    def handle_login_page(self) -> None:
        if not AUTH_ENABLED or self.session_payload():
            self.redirect("/")
            return
        try:
            body = LOGIN_FILE.read_bytes()
        except OSError:
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, "Login page unavailable")
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def handle_login(self) -> None:
        if not AUTH_ENABLED:
            self.send_json({"ok": True, "redirect": "/"})
            return
        ip = self.client_ip()
        if not login_attempt_allowed(ip):
            self.send_json(
                {"ok": False, "message": "尝试次数过多，请稍后再试"},
                status=HTTPStatus.TOO_MANY_REQUESTS,
            )
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 16_384:
            record_login_attempt(ip)
            self.send_json(
                {"ok": False, "message": "邀请码无效或已过期"},
                status=HTTPStatus.UNAUTHORIZED,
            )
            return
        raw = self.rfile.read(length)
        content_type = self.headers.get("Content-Type", "").lower()
        try:
            if "application/json" in content_type:
                payload = json.loads(raw.decode("utf-8"))
            else:
                payload = {
                    key: values[0]
                    for key, values in urllib.parse.parse_qs(
                        raw.decode("utf-8"), keep_blank_values=True
                    ).items()
                }
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError):
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        invite_token = str(payload.get("invite") or payload.get("code") or "").strip()
        invite = auth.verify_invite(invite_token)
        if not invite:
            record_login_attempt(ip)
            self.send_json(
                {"ok": False, "message": "邀请码无效或已过期"},
                status=HTTPStatus.UNAUTHORIZED,
            )
            return
        clear_login_attempts(ip)
        session_token, max_age = auth.create_session(invite)
        self.send_response(HTTPStatus.OK)
        self.set_session_cookie(session_token, max_age)
        body = json.dumps(
            {
                "ok": True,
                "redirect": self.safe_next(payload.get("next")),
                "name": invite.get("sub", ""),
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def handle_logout(self) -> None:
        body = b'{"ok":true}'
        self.send_response(HTTPStatus.OK)
        self.clear_session_cookie()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802 - stdlib handler naming
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/auth/login":
            self.handle_login()
            return
        if parsed.path == "/api/auth/logout":
            self.handle_logout()
            return
        self.send_json({"ok": False, "message": "Not found"}, status=HTTPStatus.NOT_FOUND)

    def do_GET(self) -> None:  # noqa: N802 - stdlib handler naming
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path in {"/login", "/login/"}:
            self.handle_login_page()
            return
        if path.startswith("/i/"):
            self.handle_short_invite(path)
            return
        if not AUTH_ENABLED:
            self.route_public_get(parsed)
            return
        if path in LOGIN_ASSETS or path in PUBLIC_ASSETS:
            self.serve_static(path)
            return
        if path == "/api/health":
            self.send_json(
                {
                    "ok": True,
                    "service": "hotwave",
                    "auth": "invite",
                    "cachedAt": CACHE["created"],
                    "now": time.time(),
                }
            )
            return
        if not self.require_session(parsed):
            return
        if path == "/api/auth/me":
            session = self.session_payload() or {}
            self.send_json(
                {
                    "ok": True,
                    "name": session.get("sub", ""),
                    "inviteId": session.get("jti", ""),
                    "expiresAt": session.get("exp", 0),
                }
            )
            return
        if path.startswith("/api/"):
            self.route_public_get(parsed)
            return
        self.serve_static(path)

    def route_public_get(self, parsed: urllib.parse.ParseResult) -> None:
        path = parsed.path
        if path == "/api/hot":
            query = urllib.parse.parse_qs(parsed.query)
            force = query.get("refresh", ["0"])[0] in {"1", "true", "yes"}
            try:
                payload = get_payload(force=force)
                self.send_json(payload)
            except Exception as error:  # noqa: BLE001
                self.send_json(
                    {"ok": False, "error": type(error).__name__, "message": "数据暂时不可用"},
                    status=HTTPStatus.INTERNAL_SERVER_ERROR,
                )
            return
        if path == "/api/health":
            self.send_json(
                {
                    "ok": True,
                    "service": "hotwave",
                    "auth": "invite" if AUTH_ENABLED else "off",
                    "cachedAt": CACHE["created"],
                    "now": time.time(),
                }
            )
            return
        if path.startswith("/api/"):
            self.send_json(
                {"ok": False, "message": "Not found"},
                status=HTTPStatus.NOT_FOUND,
            )
            return
        if path == "/login" or path == "/login/":
            self.redirect("/")
            return
        self.serve_static(path)

    def serve_static(self, path: str) -> None:
        decoded = urllib.parse.unquote(path)
        if decoded in {"", "/"}:
            decoded = "/index.html"
        candidate = (PUBLIC_DIR / decoded.lstrip("/")).resolve()
        try:
            candidate.relative_to(PUBLIC_DIR.resolve())
        except ValueError:
            self.send_error(HTTPStatus.FORBIDDEN)
            return

        if not candidate.is_file():
            if Path(decoded).suffix:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            candidate = PUBLIC_DIR / "index.html"
        try:
            body = candidate.read_bytes()
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return

        mime, _ = mimetypes.guess_type(candidate.name)
        content_type = mime or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {
            "application/javascript",
            "application/json",
            "image/svg+xml",
        }:
            content_type += "; charset=utf-8"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "same-origin")
        self.end_headers()
        self.wfile.write(body)


def local_ipv4_addresses() -> list[str]:
    """Best-effort discovery of LAN addresses for the startup banner."""
    addresses: set[str] = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            addresses.add(info[4][0])
    except OSError:
        pass
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.settimeout(0.2)
        probe.connect(("8.8.8.8", 80))
        addresses.add(probe.getsockname()[0])
    except OSError:
        pass
    finally:
        probe.close()
    return sorted(
        address
        for address in addresses
        if not address.startswith(("127.", "169.254."))
    )


def main() -> None:
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except AttributeError:
        pass
    try:
        auth.get_secret()
    except RuntimeError as error:
        print(f"Auth configuration error: {error}")
        raise SystemExit(1) from error
    print("=" * 58)
    print("  Hotwave - realtime trending radar")
    print(f"  Local: http://127.0.0.1:{PORT}")
    if HOST in {"0.0.0.0", "::"}:
        addresses = local_ipv4_addresses()
        if addresses:
            print("  LAN access (devices on the same Wi-Fi):")
            for address in addresses:
                print(f"    http://{address}:{PORT}")
        else:
            print("  LAN mode is on, but no IPv4 LAN address was detected")
        print("  If unreachable, allow this TCP port in Windows Firewall")
    print(f"  Access: {'invite-only' if AUTH_ENABLED else 'OPEN (HOTWAVE_AUTH=off)'}")
    if AUTH_ENABLED:
        print("  Create an invite: python invite.py create --name friend --days 14")
    print("  Cache: 3 minutes; first fetch may take a few seconds")
    print("=" * 58)
    threading.Thread(target=lambda: get_payload(force=True), daemon=True).start()
    server = ThreadingHTTPServer((HOST, PORT), HotwaveHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
