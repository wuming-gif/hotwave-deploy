param(
    [int]$Port = 8765,
    [switch]$Lan
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:PORT = "$Port"
$env:HOST = if ($Lan) { "0.0.0.0" } else { "127.0.0.1" }

$python = Get-Command python -ErrorAction SilentlyContinue
$pythonPath = $null
$pythonName = $null

if ($python) {
    $pythonPath = $python.Source
    $pythonName = $python.Name
} else {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        $pythonPath = $py.Source
        $pythonName = $py.Name
    }
}

if (-not $pythonPath) {
    $bundled = Join-Path $env:USERPROFILE ".dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    if (Test-Path $bundled) {
        $pythonPath = $bundled
        $pythonName = "python.exe"
    }
}

if (-not $pythonPath) {
    Write-Error "未找到 Python。请安装 Python 3.10+，或使用 python app.py 手动启动。"
}

Write-Host "启动沸点 Hotwave：http://127.0.0.1:$Port" -ForegroundColor Cyan
if ($Lan) {
    Write-Host "局域网模式：同一 Wi-Fi 下的朋友可访问启动时打印的局域网地址。" -ForegroundColor Yellow
}
if ($pythonName -eq "py.exe") {
    & $pythonPath -3 "app.py"
} else {
    & $pythonPath "app.py"
}
