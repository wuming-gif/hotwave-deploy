# 部署到 Render：电脑关机后也能访问

目标：把网站放到 Render 的服务器上，你的电脑可以关闭，朋友仍然可以通过邀请链接访问。

## 0. 准备

注册两个免费账号：

1. GitHub：<https://github.com/signup>
2. Render：<https://dashboard.render.com/register>，选择 **Sign up with GitHub**

## 1. 上传代码到 GitHub

1. 登录 GitHub，点击右上角 **+ → New repository**
2. 仓库名填 `hotwave`，选择 **Private**（推荐）或 Public
3. 创建后点击 **uploading an existing file**
4. 上传本项目中除以下内容之外的所有文件：
   - `data/auth_secret`
   - `data/invites_issued.json`
   - `data/invites_revoked.json`
   - 任何 `.env`
5. 点击 **Commit changes**

必须保留 `render.yaml`、`app.py`、`auth.py`、`invite.py`、`public/`、`data/fallback.json`。

## 2. 在 Render 创建服务

1. 打开 Render Dashboard
2. 点击 **New + → Blueprint**
3. 连接 GitHub，选择 `hotwave` 仓库
4. Render 会自动读取 `render.yaml`
5. 点击 **Apply / Deploy**

等待部署完成，会得到一个类似下面的地址：

```text
https://hotwave-xxxx.onrender.com
```

这时电脑已经可以关机，网站运行在 Render 上。第一次访问可能较慢，因为免费实例会冷启动。

## 3. 取得签名密钥

1. 打开 Render 上的 `hotwave` 服务
2. 进入 **Environment**
3. 找到 `HOTWAVE_SECRET`，复制它的值

这个值必须长期保持不变。更换后，所有旧邀请和登录都会失效。

## 4. 生成正式邀请链接

在你的电脑上进入项目目录，执行：

```powershell
$env:HOTWAVE_SECRET = "粘贴 Render 里的 HOTWAVE_SECRET"
python invite.py create --name "朋友" --days 30 --base-url https://hotwave-xxxx.onrender.com
```

命令会输出两条链接：

- **短链接** `/i/...`：依赖本地邀请记录，Render 临时文件系统上可能失效
- **完整邀请链接** `/login?invite=...`：自包含签名，**Render 上请使用这一条**

把完整邀请链接发给朋友。朋友点击后会看到邀请登录页，点击“进入沸点”即可。

## 5. 验证

1. 用手机流量或无痕窗口打开完整邀请链接
2. 点击“进入沸点”
3. 应该能看到热榜

如果打不开，检查：

- Render 服务是否显示 **Live**
- 邀请链接是否用了完整链接
- 本机生成邀请时，`HOTWAVE_SECRET` 是否和 Render 完全一致
- 免费实例是否正在冷启动，等待 30–60 秒再试

## 6. 免费版注意事项

- 免费实例一段时间没人访问会休眠，下次访问自动唤醒，不需要你的电脑。
- 文件系统是临时的，不要在 Render 上依赖短链接和本地撤销文件。
- 需要撤销邀请时，在 Render 的 `HOTWAVE_REVOKED_INVITES` 环境变量中填写撤销 ID，用逗号分隔，然后重新部署。
- 从海外机房抓取国内热榜可能被限流；抓取失败时页面会显示缓存数据。
- 需要更稳定、更快的国内访问，建议租一台轻量云服务器（约 30–60 元/月），用 Docker 部署并绑定域名。
