"""Signed, stateless invitation tokens for Hotwave.

Invites are self-contained HMAC tokens, so they survive restarts and work on
free hosts with ephemeral filesystems. A small local registry is kept only for
the admin CLI (listing and revoking); visitors never need a database.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
SECRET_FILE = DATA_DIR / "auth_secret"
ISSUED_FILE = DATA_DIR / "invites_issued.json"
REVOKED_FILE = DATA_DIR / "invites_revoked.json"

COOKIE_NAME = "hotwave_session"
SESSION_DAYS = 7
DEFAULT_INVITE_DAYS = 14
MAX_TOKEN_LENGTH = 4096


def _b64encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _b64decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def _write_json(path: Path, payload: Any) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback


def get_secret() -> bytes:
    """Stable signing key from env, or a generated local file for dev/LAN."""
    configured = os.environ.get("HOTWAVE_SECRET", "").strip()
    if configured:
        if len(configured) < 24:
            raise RuntimeError("HOTWAVE_SECRET must be at least 24 characters")
        return configured.encode("utf-8")

    if SECRET_FILE.exists():
        stored = SECRET_FILE.read_text(encoding="utf-8").strip()
        if len(stored) >= 24:
            return stored.encode("utf-8")

    secret = secrets.token_hex(32)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SECRET_FILE.write_text(secret, encoding="utf-8")
    try:
        os.chmod(SECRET_FILE, 0o600)
    except OSError:
        pass
    return secret.encode("utf-8")


def encode(payload: dict[str, Any]) -> str:
    body = _b64encode(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode(
            "utf-8"
        )
    )
    signature = hmac.new(get_secret(), body.encode("ascii"), hashlib.sha256).digest()
    return f"{body}.{_b64encode(signature)}"


def decode(token: str, kind: str) -> dict[str, Any] | None:
    if not token or len(token) > MAX_TOKEN_LENGTH or token.count(".") != 1:
        return None
    body, signature = token.split(".", 1)
    try:
        expected = hmac.new(
            get_secret(), body.encode("ascii"), hashlib.sha256
        ).digest()
        supplied = _b64decode(signature)
        if not hmac.compare_digest(expected, supplied):
            return None
        payload = json.loads(_b64decode(body).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None

    if not isinstance(payload, dict) or payload.get("v") != 1:
        return None
    if payload.get("kind") != kind:
        return None
    now = int(time.time())
    try:
        issued_at = int(payload["iat"])
        expires_at = int(payload["exp"])
    except (KeyError, TypeError, ValueError):
        return None
    if issued_at > now + 300 or expires_at <= now:
        return None
    return payload


def load_revoked() -> set[str]:
    values = {
        part.strip()
        for part in os.environ.get("HOTWAVE_REVOKED_INVITES", "").split(",")
        if part.strip()
    }
    stored = _read_json(REVOKED_FILE, [])
    if isinstance(stored, list):
        values.update(str(item) for item in stored if item)
    return values


def is_revoked(invite_id: str) -> bool:
    return invite_id in load_revoked()


def verify_invite(token: str) -> dict[str, Any] | None:
    payload = decode(token.strip(), "invite")
    if not payload or is_revoked(str(payload.get("jti", ""))):
        return None
    return payload


def create_session(invite: dict[str, Any], days: int = SESSION_DAYS) -> tuple[str, int]:
    now = int(time.time())
    expires_at = min(int(invite["exp"]), now + days * 86400)
    token = encode(
        {
            "v": 1,
            "kind": "session",
            "jti": invite["jti"],
            "sub": invite.get("sub", ""),
            "iat": now,
            "exp": expires_at,
        }
    )
    return token, max(0, expires_at - now)


def verify_session(token: str) -> dict[str, Any] | None:
    payload = decode(token, "session")
    if not payload or is_revoked(str(payload.get("jti", ""))):
        return None
    return payload


def _issued_records() -> list[dict[str, Any]]:
    records = _read_json(ISSUED_FILE, [])
    return records if isinstance(records, list) else []


def load_issued() -> list[dict[str, Any]]:
    return _issued_records()


def create_invite(
    name: str,
    days: int = DEFAULT_INVITE_DAYS,
    base_url: str | None = None,
) -> dict[str, Any]:
    if days < 1 or days > 365:
        raise ValueError("days must be between 1 and 365")
    clean_name = " ".join(str(name).split()).strip()[:40] or "朋友"
    now = int(time.time())
    expires_at = now + days * 86400
    invite_id = secrets.token_hex(6)
    token = encode(
        {
            "v": 1,
            "kind": "invite",
            "jti": invite_id,
            "sub": clean_name,
            "iat": now,
            "exp": expires_at,
        }
    )
    base = (
        base_url
        or os.environ.get("HOTWAVE_PUBLIC_URL", "").strip()
        or "http://127.0.0.1:8765"
    ).rstrip("/")
    url = f"{base}/login?invite={urllib.parse.quote(token)}"
    record = {
        "jti": invite_id,
        "name": clean_name,
        "createdAt": now,
        "expiresAt": expires_at,
        "url": url,
        "shortUrl": f"{base}/i/{invite_id}",
        "token": token,
    }
    records = _issued_records()
    records.append(
        {
            "jti": record["jti"],
            "name": record["name"],
            "createdAt": record["createdAt"],
            "expiresAt": record["expiresAt"],
            # Kept so the short /i/<jti> link can recover the signed token.
            "token": token,
        }
    )
    _write_json(ISSUED_FILE, records)
    return record


def find_invite_token(invite_id: str) -> str | None:
    if not invite_id:
        return None
    for record in _issued_records():
        if record.get("jti") == invite_id and isinstance(record.get("token"), str):
            return record["token"]
    return None


def revoke(jti: str) -> bool:
    clean = str(jti or "").strip()
    if not clean:
        return False
    revoked = load_revoked()
    if clean in revoked:
        return True
    stored = _read_json(REVOKED_FILE, [])
    if not isinstance(stored, list):
        stored = []
    stored.append(clean)
    _write_json(REVOKED_FILE, sorted(set(str(item) for item in stored)))
    return True


def format_timestamp(value: int | float) -> str:
    return datetime.fromtimestamp(int(value)).astimezone().strftime("%Y-%m-%d %H:%M")
